"""
SKYLOONG TERMINAL v2.1
- Modern dashboard (watchlist, candlestick chart, movers, breadth, device preview)
- Persistent memory (skyloong_config.json next to this script)
- Expandable watchlist; device shows movers first, then rotates the rest
- Separate, configurable screener (market/universe, price, volume, fundamentals,
  technicals, news & earnings)
- Price alerts pushed to the 320x240 SkyLoong display

v2.1 fixes (2026-09-22):
- Optional yfinance AsyncWebSocket stream, timestamp ordering, isolated polling fallback.
- 1-second UI checks, incremental candles, UTC timestamps and request race protection.
- 1-second minimum display push spacing independent of page rotation; HTTP validation.
- Device confirmation and generated preview distinguished; stale quote labels.
- Bounded screener workers, cancellation, filter validation, partial-failure reporting.
- Wilder RSI, explicit universe errors, and last-known cache retention.
- Compact watchlist news, newest first, deduplicated, publication timestamps to seconds.
  News is polled every 30 seconds, not a guaranteed real-time wire.
- Existing config filename/schema, saved alerts/watchlist/settings and localStorage mode
  retained. Unreadable config files are never silently overwritten.

RUN: python skyloong_terminal.py
Dependencies: Python 3.10+; flask, requests, Pillow, yfinance.
For streaming, use a yfinance version with AsyncWebSocket (otherwise polling works).
Keep this script beside your existing skyloong_config.json to retain memory.
Open http://127.0.0.1:5000 after starting it. Only run one instance per config file.
Provider/exchange delay, HTTP acknowledgements and physical LCD behaviour differ;
this program cannot guarantee tick delivery or independently read back the LCD.
"""
import io
import asyncio
import ipaddress
from zoneinfo import ZoneInfo
from urllib.parse import urlparse
import os
import json
import math
import time
import uuid
import copy
import threading
import concurrent.futures
from collections import deque
from datetime import datetime, date, timezone

import requests
import yfinance as yf
from PIL import Image, ImageDraw, ImageFont
from flask import Flask, request, jsonify, Response

# ---------------------------------------------------------------------------
# CONFIGURATION
# ---------------------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_FILE = os.path.join(BASE_DIR, "skyloong_config.json")
HTTP_TIMEOUT = 5
ROWS = 4                 # rows per device page
MARKET_REFRESH = 15       # seconds between watchlist quote refreshes
MAX_WATCHLIST = 40
NEWS_REFRESH = 30  # Provider polling, not a guaranteed second-by-second news wire.
DEVICE_MIN_PUSH = 1.0
STREAM_STALE = 20
HISTORY_TIMEOUT = 6


DEFAULT_CONFIG = {
    "ip": "192.168.100.226",
    "device_running": False,
    "selected": "BTC-USD",
    "watchlist": [
        {"name": "Bitcoin", "symbol": "BTC-USD"},
        {"name": "DELL", "symbol": "DELL"},
        {"name": "Dow Jones", "symbol": "^DJI"},
        {"name": "S&P 500", "symbol": "^GSPC"},
    ],
    "display": {
        "page_seconds": 6,
        "alert_seconds": 6,
        "mover_pct": 1.0,       # |day change| % that qualifies as a mover
        "momentum_pct": 0.3,    # |5-minute change| % that qualifies as a mover
    },
    "alerts": [],
    "screener": {
        "enabled": False,
        "universe": "preset:us_momentum",
        "custom_symbols": "",
        "direction": "any",
        "change_min": 2.0,
        "gap_min": None,
        "price_min": None,
        "price_max": None,
        "near_high_pct": None,
        "volume_min": None,
        "rel_volume_min": None,
        "mcap_min_b": None,
        "mcap_max_b": None,
        "pe_min": None,
        "pe_max": None,
        "eps_min": None,
        "eps_growth_min": None,
        "div_yield_min": None,
        "rating": "any",
        "sector": "",
        "rsi_min": None,
        "rsi_max": None,
        "above_sma50": False,
        "above_sma200": False,
        "news_hours": None,
        "news_keyword": "",
        "earnings_days": None,
        "show_headlines": True,
        "scan_interval": 180,
        "max_results": 50,
        "sort_by": "abs_change",
        "push_to_display": True,
    },
}

UNIVERSES = {
    "local:watchlist": ("My Lists", "My Watchlist", []),
    "custom": ("My Lists", "Custom Symbols", []),
    "preset:us_mega": ("United States", "US Mega Caps", [
        "AAPL", "MSFT", "NVDA", "AMZN", "GOOGL", "META", "TSLA", "AVGO", "BRK-B", "JPM",
        "LLY", "V", "UNH", "XOM", "MA", "COST", "NFLX", "AMD", "ORCL", "CRM"]),
    "preset:us_momentum": ("United States", "US High-Beta / Momentum", [
        "NVDA", "TSLA", "AMD", "PLTR", "COIN", "MSTR", "SMCI", "RIVN", "SOFI", "HOOD",
        "MARA", "RIOT", "ARM", "SNOW", "SHOP", "UBER", "AMZN", "AAPL", "MSFT", "META"]),
    "preset:us_etf": ("United States", "US Index & Sector ETFs", [
        "SPY", "QQQ", "IWM", "DIA", "XLK", "XLF", "XLE", "XLV", "XLY", "XLI", "XLP",
        "XLU", "XLB", "XLRE", "XLC", "SMH", "ARKK", "GLD", "SLV", "TLT"]),
    "yahoo:day_gainers": ("United States", "Yahoo: Day Gainers", []),
    "yahoo:day_losers": ("United States", "Yahoo: Day Losers", []),
    "yahoo:most_actives": ("United States", "Yahoo: Most Active", []),
    "yahoo:small_cap_gainers": ("United States", "Yahoo: Small-Cap Gainers", []),
    "yahoo:growth_technology_stocks": ("United States", "Yahoo: Growth Tech", []),
    "yahoo:undervalued_growth_stocks": ("United States", "Yahoo: Undervalued Growth", []),
    "yahoo:undervalued_large_caps": ("United States", "Yahoo: Undervalued Large Caps", []),
    "yahoo:most_shorted_stocks": ("United States", "Yahoo: Most Shorted", []),
    "preset:nifty": ("India", "NIFTY 50 Leaders", [
        "RELIANCE.NS", "TCS.NS", "HDFCBANK.NS", "INFY.NS", "ICICIBANK.NS", "HINDUNILVR.NS",
        "ITC.NS", "SBIN.NS", "BHARTIARTL.NS", "KOTAKBANK.NS", "LT.NS", "AXISBANK.NS",
        "BAJFINANCE.NS", "ASIANPAINT.NS", "MARUTI.NS", "TITAN.NS", "SUNPHARMA.NS",
        "TATAMOTORS.NS", "WIPRO.NS", "HCLTECH.NS"]),
    "preset:uk": ("United Kingdom", "FTSE 100 Leaders", [
        "SHEL.L", "AZN.L", "HSBA.L", "ULVR.L", "BP.L", "GSK.L", "RIO.L", "BATS.L",
        "DGE.L", "LSEG.L", "REL.L", "BARC.L", "LLOY.L", "VOD.L", "NG.L", "GLEN.L"]),
    "preset:saudi": ("Middle East", "Saudi Tadawul Leaders", [
        "2222.SR", "1120.SR", "2010.SR", "7010.SR", "1180.SR", "2082.SR", "1211.SR",
        "1150.SR", "2280.SR", "4190.SR"]),
    "preset:crypto": ("Crypto", "Top Crypto", [
        "BTC-USD", "ETH-USD", "SOL-USD", "BNB-USD", "XRP-USD", "ADA-USD", "DOGE-USD",
        "AVAX-USD", "LINK-USD", "DOT-USD", "LTC-USD", "BCH-USD"]),
}

app = Flask(__name__)

# ---------------------------------------------------------------------------
# STATE
# ---------------------------------------------------------------------------
LOCK = threading.RLock()
CACHE_LOCK = threading.Lock()
SCAN_LOCK = threading.Lock()

QUOTES = {}
ALERT_DISPLAY_QUEUE = deque(maxlen=20)
EVENTS = deque(maxlen=200)
PREVIEW = {"bytes": None, "version": 0, "label": "", "symbols": []}
DEVICE = {"label": "", "symbols": [], "last_push": None, "error": None,
          "last_attempt": None, "confirmed_ip": None, "status": "stopped"}
FEED = {"mode": "starting", "error": None, "last_tick": None}
NEWS_STATUS = {"last_check": None, "error": None, "refresh_seconds": NEWS_REFRESH}
WATCHLIST_NEWS = []
NEWS_WAKE = threading.Event()
PRICE_SAMPLES = {}
LIVE_BARS = {}
CACHE_INFLIGHT = {}
CACHE_ERRORS = {}
HISTORY_DAILY_CACHE = {}
SCR_CONTROL = threading.Lock()
SCR_REVISION = 0
SCREEN_POOL = concurrent.futures.ThreadPoolExecutor(max_workers=4, thread_name_prefix="screen")
HEADLINE_POOL = concurrent.futures.ThreadPoolExecutor(max_workers=2, thread_name_prefix="headlines")
SCR_REQUESTED = False


MARKET_WAKE = threading.Event()
DEVICE_WAKE = threading.Event()

SCR_THREAD = None
SCR_STOP = threading.Event()
SCR_WAKE = threading.Event()
SCREENER_STATUS = {"scanning": False, "progress": 0, "total": 0, "last_scan": None,
                   "next_scan": None, "duration": None, "universe_label": "",
                   "matched": 0, "error": None}
SCREENER_RESULTS = []
SCREENER_ANNOUNCED = {"day": None, "symbols": set()}

PREV_CLOSE_CACHE = {}
FUND_CACHE, NEWS_CACHE, CAL_CACHE = {}, {}, {}
UNIVERSE_CACHE, DETAIL_CACHE, HISTORY_CACHE, QUOTE_CACHE = {}, {}, {}, {}

# ---------------------------------------------------------------------------
# CONFIG PERSISTENCE
# ---------------------------------------------------------------------------

def deep_merge(base, override):
    out = copy.deepcopy(base)
    for k, v in (override or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def load_config():
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                stored = json.load(f)
                if not isinstance(stored, dict):
                    raise ValueError("Configuration must be a JSON object")
                return deep_merge(DEFAULT_CONFIG, stored)
        except Exception as e:
            raise RuntimeError(f"Cannot read {CONFIG_FILE}; original memory file left untouched: {e}") from e
    return copy.deepcopy(DEFAULT_CONFIG)


def save_config():
    """Caller should hold LOCK."""
    tmp = CONFIG_FILE + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(CONFIG, f, indent=2, allow_nan=False)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, CONFIG_FILE)
    except Exception as e:
        raise OSError(f"Could not save configuration: {e}") from e


CONFIG = load_config()

# ---------------------------------------------------------------------------
# HELPERS
# ---------------------------------------------------------------------------

def num(v):
    try:
        f = float(v)
        return None if math.isnan(f) or math.isinf(f) else f
    except (TypeError, ValueError):
        return None


def log_event(kind, msg):
    with LOCK:
        EVENTS.appendleft({"ts": time.time(), "kind": kind, "msg": msg})
    print(f"[{kind.upper()}] {msg}")


def cached(cache, key, ttl, fn, default=None):
    """Single-flight cache; retain the last good result after transient failures."""
    token = (id(cache), key)
    with CACHE_LOCK:
        hit = cache.get(key)
        if hit and time.time() - hit[0] < ttl:
            return hit[1]
        pending = CACHE_INFLIGHT.get(token)
        owner = pending is None
        if owner:
            pending = threading.Event()
            CACHE_INFLIGHT[token] = pending
    if not owner:
        if hit:
            return hit[1]
        pending.wait(HISTORY_TIMEOUT + 2)
        with CACHE_LOCK:
            return cache.get(key, (0, default))[1]
    try:
        val = fn()
        with CACHE_LOCK:
            cache[key] = (time.time(), val)
            CACHE_ERRORS.pop(token, None)
            if len(cache) > 600:
                oldest = min(cache, key=lambda k: cache[k][0])
                cache.pop(oldest, None)
        return val
    except Exception as e:
        with CACHE_LOCK:
            CACHE_ERRORS[token] = str(e)[:180]
            val = hit[1] if hit else default
            cache[key] = (time.time() - ttl + min(ttl, 5), val)
        print(f"Fetch error {key}: {e}")
        return val
    finally:
        with CACHE_LOCK:
            CACHE_INFLIGHT.pop(token, None)
            pending.set()


def last_session(df):
    if df is None or df.empty:
        return df
    last_day = df.index[-1].date()
    return df[df.index.date == last_day]


def downsample(seq, n=60):
    seq = list(seq)
    if len(seq) <= n:
        return seq
    step = (len(seq) - 1) / (n - 1)
    return [seq[round(i * step)] for i in range(n)]


def empty_quote(symbol, name=None):
    return {"symbol": symbol, "name": name or symbol, "price": None, "prev_close": None,
            "change": None, "pct": None, "momentum": None, "high": None, "low": None,
            "open": None, "volume": None, "spark": [], "updated": None, "ok": False,
            "error": None}


def annotate(q, disp):
    pct = abs(q.get("pct") or 0)
    mom = abs(q.get("momentum") or 0)
    q["score"] = pct + 2 * mom
    q["mover"] = bool(q.get("ok")) and (pct >= disp["mover_pct"] or mom >= disp["momentum_pct"])
    return q

# ---------------------------------------------------------------------------
# MARKET DATA
# ---------------------------------------------------------------------------

def fetch_quote(symbol):
    t = yf.Ticker(symbol)
    intraday = last_session(t.history(period="5d", interval="1m", timeout=HISTORY_TIMEOUT, raise_errors=True))
    if intraday is None or intraday.empty:
        raise ValueError("no intraday data")
    closes = [c for c in (num(x) for x in intraday["Close"].tolist()) if c is not None]
    if not closes:
        raise ValueError("no valid closes")

    session = intraday.index[-1].date()
    key = (symbol, session)
    prev = PREV_CLOSE_CACHE.get(key)
    if prev is None:
        daily = t.history(period="10d", interval="1d", timeout=HISTORY_TIMEOUT, raise_errors=True)
        prior = daily[daily.index.date < session] if not daily.empty else daily
        prev = num(prior["Close"].iloc[-1]) if not prior.empty else None
        if prev is None:
            prev = num(intraday["Open"].iloc[0]) or closes[0]
        PREV_CLOSE_CACHE[key] = prev
        for old_key in list(PREV_CLOSE_CACHE):
            if old_key[0] == symbol and old_key != key:
                PREV_CLOSE_CACHE.pop(old_key, None)

    price = closes[-1]
    change = price - prev
    pct = change / prev * 100 if prev else 0.0
    ref = closes[-6] if len(closes) >= 6 else closes[0]
    momentum = (price - ref) / ref * 100 if ref else 0.0
    return {
        "symbol": symbol, "name": symbol, "price": price, "prev_close": prev,
        "change": change, "pct": pct, "momentum": momentum,
        "high": num(intraday["High"].max()), "low": num(intraday["Low"].min()),
        "open": num(intraday["Open"].iloc[0]), "volume": num(intraday["Volume"].sum()),
        "spark": downsample(closes, 60), "session": str(session),
        "updated": time.time(), "market_time": intraday.index[-1].timestamp(),
        "source": "minute history", "timezone": str(intraday.index.tz or "UTC"),
        "ok": True, "error": None,
    }


def get_live_price(symbol):
    with LOCK:
        q = QUOTES.get(symbol)
        if q and q.get("ok") and q.get("price") and time.time() - (q.get("updated") or 0) < 60:
            return q["price"]
    try:
        t = yf.Ticker(symbol)
        try:
            p = num(getattr(t.fast_info, "last_price"))
        except Exception:
            p = None
        if p and p > 0:
            return p
        h = t.history(period="5d", interval="1m", timeout=HISTORY_TIMEOUT, raise_errors=True)
        if not h.empty:
            return num(h["Close"].iloc[-1]) or 0.0
    except Exception as e:
        print(f"Price error {symbol}: {e}")
    return 0.0


def get_detail(symbol):
    fi = yf.Ticker(symbol).fast_info
    out = {}
    for k in ["day_high", "day_low", "year_high", "year_low", "market_cap", "last_volume",
              "previous_close", "open", "fifty_day_average", "two_hundred_day_average",
              "currency", "exchange", "quote_type"]:
        try:
            v = getattr(fi, k)
            out[k] = v if isinstance(v, str) else num(v)
        except Exception:
            out[k] = None
    return out


HIST_RANGES = {
    "1D": ("5d", "1m", True, 15),
    "5D": ("5d", "15m", False, 60),
    "1M": ("1mo", "60m", False, 300),
    "6M": ("6mo", "1d", False, 900),
    "1Y": ("1y", "1d", False, 900),
    "5Y": ("5y", "1wk", False, 3600),
}


def get_history(symbol, rng):
    period, interval, last_only, _ = HIST_RANGES[rng]
    h = yf.Ticker(symbol).history(period=period, interval=interval, timeout=HISTORY_TIMEOUT, raise_errors=True)
    if last_only:
        h = last_session(h)
    bars, last_t = [], None
    for ts, row in h.iterrows():
        o, hi, lo, c = num(row["Open"]), num(row["High"]), num(row["Low"]), num(row["Close"])
        if None in (o, hi, lo, c):
            continue
        t = int(ts.timestamp())  # True UTC epoch; never add the exchange offset.
        if last_t is not None and t <= last_t:
            continue
        last_t = t
        bars.append({"time": t, "open": o, "high": hi, "low": lo, "close": c,
                     "volume": num(row.get("Volume")) or 0, "retrieved_at": time.time()})
    return bars


def merge_live_history(sym, rng, bars):
    """Overlay streamed trades on intraday bars; never fabricate traded volume."""
    if rng not in ("1D", "5D", "1M"):
        return bars
    with LOCK:
        live = copy.deepcopy(LIVE_BARS.get(sym, {}))
        q = dict(QUOTES.get(sym) or {})
    out = {b["time"]: dict(b) for b in bars}
    if not out:
        return bars
    width = {"1D": 60, "5D": 900, "1M": 3600}[rng]
    earliest = min(out)
    tz = ZoneInfo(q.get("timezone") or "UTC")
    last_day = datetime.fromtimestamp(max(out), tz).date()
    for ts, b in sorted(live.items()):
        if ts < earliest:
            continue
        if rng == "1D" and datetime.fromtimestamp(ts, tz).date() > last_day:
            out.clear()
            last_day = datetime.fromtimestamp(ts, tz).date()
        # Anchor larger buckets to provider bars (some markets open at :15/:30).
        anchor = max((t for t in out if t <= ts), default=ts // width * width)
        bucket = anchor + ((ts - anchor) // width) * width
        if bucket in out:
            old = out[bucket]
            old.update(high=max(old["high"], b["high"]), low=min(old["low"], b["low"]))
            if b.get("trade_time", ts) >= old.get("retrieved_at", 0):
                old["close"] = b["close"]
        else:
            out[bucket] = dict(b, time=bucket)
    return [out[t] for t in sorted(out)]


def check_active_alerts(symbol, price):
    fired = []
    with LOCK:
        for a in CONFIG["alerts"]:
            if a["symbol"] != symbol or a["triggered"]:
                continue
            tgt, cond = a["target_price"], a["condition"]
            if (cond == ">=" and price >= tgt) or (cond == "<=" and price <= tgt):
                a["triggered"] = True
                a["triggered_at"] = time.time()
                a["triggered_price"] = price
                item = dict(a)
                item["current_price"] = price
                item["message"] = f"HIT {cond} {tgt:,.2f}"
                ALERT_DISPLAY_QUEUE.append(item)
                fired.append(a)
        if fired:
            save_config()
    if fired:
        DEVICE_WAKE.set()
    for a in fired:
        log_event("alert", f"{a['symbol']} hit {a['condition']} {a['target_price']:,.2f} (now {price:,.2f})")


def tracked_symbols():
    with LOCK:
        names = {w["symbol"]: w["name"] for w in CONFIG["watchlist"]}
        for a in CONFIG["alerts"]:
            if not a["triggered"]:
                names.setdefault(a["symbol"], a.get("name") or a["symbol"])
        if CONFIG.get("selected"):
            names.setdefault(CONFIG["selected"], CONFIG["selected"])
        return names


def quote_state(q):
    q = dict(q)
    age = time.time() - (q.get("market_time") or 0)
    q["stale"] = bool(q.get("error")) or not q.get("ok") or age > 120
    q["freshness"] = ("unavailable" if not q.get("ok") else
                      "fetch error; last known" if q.get("error") else
                      "live stream" if q.get("source") == "stream" and age <= STREAM_STALE else
                      "delayed / closed" if age > 120 else "polled")
    return q


def publish_quote(symbol, q):
    """A history response must never overwrite a newer streaming price."""
    with LOCK:
        old = QUOTES.get(symbol, {})
        if (old.get("market_time") or 0) > (q.get("market_time") or 0) or (old.get("source") == "stream" and old.get("market_time") == q.get("market_time")):
            merged = dict(q)
            merged.update({k: v for k, v in old.items() if v is not None})
            # History supplies the exchange timezone/session metadata at startup.
            for k in ("timezone", "session"):
                if q.get(k):
                    merged[k] = q[k]
            QUOTES[symbol] = merged
            return
        QUOTES[symbol] = q
    DEVICE_WAKE.set()
    if q.get("ok") and not q.get("error") and time.time() - (q.get("market_time") or 0) < 120:
        check_active_alerts(symbol, q["price"])


def handle_stream_message(message):
    if not isinstance(message, dict):
        return
    sym = str(message.get("id") or "").upper()
    price, stamp = num(message.get("price")), num(message.get("time"))
    if sym not in tracked_symbols() or price is None or price <= 0 or not stamp:
        return
    if stamp > 1e11:
        stamp /= 1000.0
    now = time.time()
    if stamp > now + 60:
        return
    with LOCK:
        old = QUOTES.get(sym) or empty_quote(sym)
        if stamp < (old.get("market_time") or 0):
            return
        q = dict(old)
        change, pct = num(message.get("change")), num(message.get("change_percent"))
        prev = price - change if change is not None else q.get("prev_close")
        q.update(symbol=sym, name=tracked_symbols().get(sym, sym), price=price,
                 prev_close=prev, change=price-prev if prev else change,
                 pct=(price-prev)/prev*100 if prev else pct,
                 market_time=stamp, updated=now, source="stream", ok=True, error=None)
        q["market_hours"] = message.get("market_hours")
        for incoming, field in (("day_high", "high"), ("day_low", "low"), ("day_volume", "volume")):
            value = num(message.get(incoming))
            if value is not None and value >= 0:
                q[field] = value
        samples = PRICE_SAMPLES.setdefault(sym, deque(maxlen=1200))
        samples.append((stamp, price))
        while len(samples) > 1 and samples[1][0] < stamp - 300:
            samples.popleft()
        if samples and stamp - samples[0][0] >= 240:
            q["momentum"] = (price / samples[0][1] - 1) * 100
        minute = int(stamp // 60 * 60)
        live = LIVE_BARS.setdefault(sym, {})
        bar = live.get(minute)
        if bar:
            bar.update(high=max(bar["high"], price), low=min(bar["low"], price), close=price, trade_time=stamp)
        else:
            live[minute] = {"time": minute, "open": price, "high": price,
                            "low": price, "close": price, "volume": 0, "trade_time": stamp}
        if len(live) > 600:
            live.pop(min(live))
        spark = list(q.get("spark") or [])
        if q.get("spark_minute") == minute and spark:
            spark[-1] = price
        else:
            spark.append(price)
        q["spark"], q["spark_minute"] = spark[-60:], minute
        QUOTES[sym] = q
        FEED.update(mode="streaming", last_tick=now, error=None)
    DEVICE_WAKE.set()
    if now - stamp < 120:
        check_active_alerts(sym, price)


async def stream_session():
    async with yf.AsyncWebSocket(verbose=False) as ws:
        subscribed = set(tracked_symbols())
        if subscribed:
            await ws.subscribe(sorted(subscribed))
        listener = asyncio.create_task(ws.listen(handle_stream_message))
        try:
            while not listener.done():
                await asyncio.sleep(2)
                wanted = set(tracked_symbols())
                if wanted - subscribed:
                    await asyncio.wait_for(ws.subscribe(sorted(wanted - subscribed)), 10)
                if subscribed - wanted:
                    await asyncio.wait_for(ws.unsubscribe(sorted(subscribed - wanted)), 10)
                subscribed = wanted
            await listener
        finally:
            listener.cancel()
            await asyncio.gather(listener, return_exceptions=True)


def stream_loop():
    if not hasattr(yf, "AsyncWebSocket"):
        with LOCK:
            FEED.update(mode="polling", error="Update yfinance to enable streaming")
        return
    while True:
        try:
            with LOCK:
                FEED["mode"] = "connecting"
            asyncio.run(stream_session())
        except Exception as e:
            with LOCK:
                FEED.update(mode="polling", error=str(e)[:160])
        time.sleep(5)


def market_loop():
    # A slow symbol cannot hold back the rest; at most one fetch per symbol.
    executor = concurrent.futures.ThreadPoolExecutor(max_workers=4, thread_name_prefix="quotes")
    pending, due = {}, {}
    while True:
        names = tracked_symbols()
        now = time.monotonic()
        for sym, future in list(pending.items()):
            if not future.done():
                continue
            pending.pop(sym)
            if sym not in names:
                continue
            try:
                q = future.result()
                q["name"] = names[sym]
                publish_quote(sym, q)
            except Exception as e:
                with LOCK:
                    q = dict(QUOTES.get(sym) or empty_quote(sym, names[sym]))
                    if time.time() - (q.get("updated") or 0) > STREAM_STALE:
                        q["error"] = str(e)[:160]
                        QUOTES[sym] = q
            with LOCK:
                latest = QUOTES.get(sym) or {}
                fresh_stream = latest.get("source") == "stream" and time.time() - (latest.get("updated") or 0) < STREAM_STALE
            due[sym] = now + (60 if fresh_stream else MARKET_REFRESH)
        with LOCK:
            for sym in list(QUOTES):
                if sym not in names:
                    QUOTES.pop(sym, None)
                    PRICE_SAMPLES.pop(sym, None)
                    LIVE_BARS.pop(sym, None)
                    due.pop(sym, None)
        for sym in names:
            if sym not in pending and now >= due.get(sym, 0):
                with LOCK:
                    q = QUOTES.get(sym) or {}
                    streamed = q.get("source") == "stream" and time.time() - (q.get("updated") or 0) < STREAM_STALE
                # Refresh history/metadata periodically even when streaming works.
                interval = 60 if streamed else MARKET_REFRESH
                if now < due.get(sym, 0):
                    continue
                pending[sym] = executor.submit(fetch_quote, sym)
                due[sym] = now + interval
        MARKET_WAKE.wait(0.25)
        MARKET_WAKE.clear()



# ---------------------------------------------------------------------------
# DEVICE PAGE SCHEDULER  (movers first, then rotate the rest)
# ---------------------------------------------------------------------------

class PageScheduler:
    def __init__(self):
        self.movers_turn = True
        self.rest_ptr = 0
        self.all_ptr = 0

    @staticmethod
    def plan(quotes, disp):
        qs = [annotate(dict(q), disp) for q in quotes]
        if not qs:
            return []
        ranked = sorted(qs, key=lambda q: q["score"], reverse=True)
        if len(qs) <= ROWS:
            return [("WATCHLIST", ranked)]
        n_all = math.ceil(len(ranked) / ROWS)
        movers = [q for q in ranked if q["mover"]]
        if not movers:
            return [(f"WATCHLIST {i + 1}/{n_all}", ranked[i * ROWS:(i + 1) * ROWS]) for i in range(n_all)]
        top = movers[:ROWS]
        if len(top) < ROWS:
            top += [q for q in ranked if not q["mover"]][:ROWS - len(top)]
        top_syms = {q["symbol"] for q in top}
        rest = [q for q in qs if q["symbol"] not in top_syms]   # keep watchlist order
        n = math.ceil(len(rest) / ROWS)
        pages = [("TOP MOVERS", top)]
        pages += [(f"WATCHLIST {i + 1}/{n}", rest[i * ROWS:(i + 1) * ROWS]) for i in range(n)]
        return pages

    def next_page(self, quotes, disp):
        pages = self.plan(quotes, disp)
        if not pages:
            return "NO TICKERS", []
        if len(pages) == 1:
            return pages[0]
        if pages[0][0] == "TOP MOVERS":
            # Movers page is shown every other slot; the rest rotate in between
            if self.movers_turn:
                self.movers_turn = False
                return pages[0]
            self.movers_turn = True
            rest = pages[1:]
            p = rest[self.rest_ptr % len(rest)]
            self.rest_ptr += 1
            return p
        p = pages[self.all_ptr % len(pages)]
        self.all_ptr += 1
        return p


SCHED = PageScheduler()

# ---------------------------------------------------------------------------
# DEVICE RENDERING
# ---------------------------------------------------------------------------

def load_font(name, size):
    try:
        return ImageFont.truetype(f"C:\\Windows\\Fonts\\{name}", size)
    except IOError:
        return ImageFont.load_default()


FONT_LG_BOLD = load_font("arialbd.ttf", 15)
FONT_MD_BOLD = load_font("arialbd.ttf", 12)
FONT_SM_BOLD = load_font("arialbd.ttf", 10)
FONT_SM_REG = load_font("arial.ttf", 11)

GREEN = (46, 211, 160)
RED = (240, 80, 110)
GREY = (120, 128, 150)
ACCENT = (139, 125, 255)
BG = (7, 11, 25)


def draw_right_aligned_text(draw, text, font, x_right, y, fill):
    bbox = font.getbbox(text)
    draw.text((x_right - (bbox[2] - bbox[0]), y), text, font=font, fill=fill)


def draw_change_box(draw, text, font, x_right, y, bg_color):
    bbox_ref = font.getbbox("09+.%")
    bbox_text = font.getbbox(text)
    w = bbox_text[2] - bbox_text[0]
    h = bbox_ref[3] - bbox_ref[1]
    pad_x, pad_y = 6, 4
    left = x_right - (w + pad_x * 2)
    draw.rounded_rectangle([left, y, x_right, y + h + pad_y * 2], radius=4, fill=bg_color)
    draw.text((left + pad_x, y + pad_y), text, font=font, fill=(255, 255, 255))


def draw_area_chart(draw, x, y, w, h, data, prev_close, color):
    if not data or len(data) < 2:
        return
    vals = list(data) + ([prev_close] if prev_close else [])
    mn, mx = min(vals), max(vals)
    rng = (mx - mn) or 1
    pts = [(x + i / (len(data) - 1) * w, y + h - (v - mn) / rng * h) for i, v in enumerate(data)]
    dim = tuple(int(c * 0.3) for c in color)
    draw.polygon([(pts[0][0], y + h)] + pts + [(pts[-1][0], y + h)], fill=dim)
    draw.line(pts, fill=color, width=1)
    if prev_close:
        py = y + h - (prev_close - mn) / rng * h
        for dx in range(0, int(w), 6):
            draw.line([(x + dx, py), (x + dx + 2, py)], fill=(90, 98, 130))


def to_jpeg(img):
    buf = io.BytesIO()
    img.save(buf, "JPEG", quality=88, subsampling=0)
    return buf.getvalue()


def render_page(quotes, label):
    img = Image.new("RGB", (320, 240), color=BG)
    draw = ImageDraw.Draw(img)
    draw.rectangle([0, 0, 320, 19], fill=(17, 24, 48))
    lbl_color = ACCENT if label.startswith("TOP") else (160, 170, 200)
    draw.text((8, 4), label, font=FONT_SM_BOLD, fill=lbl_color)
    draw_right_aligned_text(draw, time.strftime("%H:%M"), FONT_SM_BOLD, 312, 4, (160, 170, 200))

    if not quotes:
        draw.text((20, 110), "ADD TICKERS IN THE WEB UI", font=FONT_MD_BOLD, fill=(160, 170, 200))
        return img

    row_h, y0 = 55, 21
    for i, q in enumerate(quotes):
        y = y0 + i * row_h
        ok = q.get("ok") and q.get("price")
        change = q.get("change") or 0
        color = (GREEN if change >= 0 else RED) if ok else GREY
        if q.get("stale"):
            draw.text((130, y + 2), "OLD", font=FONT_SM_BOLD, fill=GREY)
        if q.get("mover"):
            draw.rectangle([0, y + 8, 2, y + row_h - 8], fill=color)
        draw.text((10, y + 8), (q.get("name") or q["symbol"])[:14], font=FONT_LG_BOLD, fill=(255, 255, 255))
        draw.text((10, y + 29), q["symbol"], font=FONT_SM_REG, fill=(140, 150, 180))
        draw_area_chart(draw, 150, y + 14, 70, 24, q.get("spark"), q.get("prev_close"), color)
        price_txt = f"{q['price']:,.2f}" if ok else "--"
        draw_right_aligned_text(draw, price_txt, FONT_LG_BOLD, 315, y + 6, (255, 255, 255))
        pct = q.get("pct")
        pct_txt = f"{'+' if (pct or 0) >= 0 else ''}{pct:.2f}%" if ok and pct is not None else "--"
        draw_change_box(draw, pct_txt, FONT_MD_BOLD, 315, y + 27, color)
        if i < len(quotes) - 1:
            draw.line([(10, y + row_h - 1), (315, y + row_h - 1)], fill=(30, 38, 66), width=1)
    return img


def render_alert(alert_item):
    img = Image.new("RGB", (320, 240), color=(20, 4, 12))
    draw = ImageDraw.Draw(img)
    is_scr = alert_item.get("condition") is None
    head = (109, 93, 252) if is_scr else (234, 51, 35)
    draw.rectangle([5, 5, 315, 235], outline=head, width=3)
    draw.rectangle([8, 8, 312, 45], fill=head)
    draw.text((15, 17), "SCREENER HIT" if is_scr else "! PRICE ALERT TRIGGERED !",
              font=FONT_LG_BOLD, fill=(255, 255, 255))

    target = alert_item.get("target_price") or 0.0
    current = alert_item.get("current_price") or 0.0
    cond = alert_item.get("condition")
    hit = True if cond is None else (current <= target if cond == "<=" else current >= target)

    draw.text((15, 60), f"TICKER: {alert_item.get('symbol', '?')}", font=FONT_LG_BOLD, fill=(255, 204, 0))
    draw.text((15, 85), f"{(alert_item.get('name') or '')[:30]}", font=FONT_SM_REG, fill=(200, 200, 200))
    if not is_scr:
        draw.text((15, 115), f"TARGET:  {target:,.2f}", font=FONT_MD_BOLD, fill=(255, 255, 255))
    draw.text((15, 140), f"PRICE:   {current:,.2f}", font=FONT_LG_BOLD, fill=GREEN if hit else RED)
    draw.line([(15, 175), (305, 175)], fill=(80, 80, 100), width=1)
    draw.text((15, 190), f">> {alert_item.get('message', '').upper()}"[:40], font=FONT_MD_BOLD, fill=(255, 204, 0))
    draw.text((15, 212), time.strftime("%H:%M:%S"), font=FONT_SM_REG, fill=(140, 140, 160))
    return img


DEVICE_HTTP = requests.Session()


def push_to_device(ip, data):
    try:
        r = DEVICE_HTTP.post(f"http://{ip}/edit", files={"data": ("stocks.jpg", data, "image/jpeg")},
                             timeout=(2, HTTP_TIMEOUT))
        r.raise_for_status()
        r = DEVICE_HTTP.post(f"http://{ip}/config_app_jpg",
                             params={"enable": "true", "time_roll": "5000", "jpg_mode": "fixed",
                                     "jpg_file": "stocks.jpg"}, timeout=(2, HTTP_TIMEOUT))
        r.raise_for_status()
        return None
    except requests.RequestException as e:
        return str(e).split("(Caused")[0][:160]


def device_snapshot():
    d = dict(DEVICE, running=CONFIG["device_running"], ip=CONFIG["ip"])
    if not d["running"]:
        d["status"] = "stopped"
    elif d["error"]:
        d["status"] = "unreachable"
    elif d["confirmed_ip"] != d["ip"] or not d["last_push"]:
        d["status"] = "connecting"
    elif time.time() - d["last_push"] > max(15, CONFIG["display"]["page_seconds"] + 12):
        d["status"] = "stale"
    else:
        d["status"] = "confirmed"
    if d["status"] != "confirmed":
        d["symbols"] = []  # Do not claim that the preview is on the physical screen.
    d["preview_version"] = PREVIEW["version"]
    d["preview_label"] = PREVIEW["label"]
    return d


def device_loop():
    page_syms, label, active_alert = [], "", None
    page_until = 0
    last_signature, next_push, last_err = None, 0, None
    last_target = None
    while True:
        try:
            now = time.monotonic()
            with LOCK:
                running, ip = CONFIG["device_running"], CONFIG["ip"]
                disp = dict(CONFIG["display"])
                quotes = [quote_state(dict(QUOTES.get(w["symbol"]) or empty_quote(w["symbol"]), name=w["name"]))
                          for w in CONFIG["watchlist"]]
                if last_target != (running, ip):
                    last_signature, next_push = None, 0
                    last_target = (running, ip)
                if active_alert and now >= page_until:
                    active_alert = None
                if running and not active_alert and ALERT_DISPLAY_QUEUE:
                    active_alert = ALERT_DISPLAY_QUEUE.popleft()
                    page_until = now + disp["alert_seconds"]
                if active_alert:
                    img = render_alert(active_alert)
                    label, syms = "ALERT", [active_alert.get("symbol")]
                else:
                    current = {q["symbol"]: q for q in quotes}
                    if now >= page_until or not page_syms or any(s not in current for s in page_syms):
                        label, page = SCHED.next_page(quotes, disp)
                        page_syms = [q["symbol"] for q in page]
                        page_until = now + disp["page_seconds"]
                    page = [annotate(dict(current[s]), disp) for s in page_syms if s in current]
                    img, syms = render_page(page, label), page_syms
            data = to_jpeg(img)
            signature = (data, running, ip)
            if now >= next_push and (signature != last_signature or running and
                                     time.time() - (DEVICE.get("last_push") or 0) >= 5):
                with LOCK:
                    if data != PREVIEW["bytes"]:
                        PREVIEW.update(bytes=data, label=label, symbols=list(syms), version=PREVIEW["version"] + 1)
                    if running:
                        DEVICE["last_attempt"] = time.time()
                err = push_to_device(ip, data) if running else None
                with LOCK:
                    # An old in-flight response must not confirm a newly selected target.
                    if running and CONFIG["device_running"] and CONFIG["ip"] == ip:
                        DEVICE["error"] = err
                        if not err:
                            DEVICE.update(label=label, symbols=list(syms), last_push=time.time(), confirmed_ip=ip)
                    elif not CONFIG["device_running"]:
                        DEVICE["error"] = None
                if err and err != last_err:
                    log_event("device", f"Push to {ip} failed: {err}")
                elif running and not err and last_err:
                    log_event("device", f"Connection to {ip} restored")
                last_err = err
                last_signature = signature if not err else None
                next_push = time.monotonic() + (3 if err else DEVICE_MIN_PUSH)
        except Exception as e:
            with LOCK:
                DEVICE["error"] = str(e)[:160]
            next_push = time.monotonic() + 3
            print(f"Device loop error: {e}")
        DEVICE_WAKE.wait(0.25)
        DEVICE_WAKE.clear()



# ---------------------------------------------------------------------------
# SCREENER
# ---------------------------------------------------------------------------

def rsi(close, n=14):
    if len(close) < n + 1:
        return None
    delta = close.diff().dropna()
    gains, losses = delta.clip(lower=0), -delta.clip(upper=0)
    gain, loss = float(gains.iloc[:n].mean()), float(losses.iloc[:n].mean())
    for g, l in zip(gains.iloc[n:], losses.iloc[n:]):
        gain, loss = (gain * (n - 1) + g) / n, (loss * (n - 1) + l) / n
    if loss == 0:
        return 50.0 if gain == 0 else 100.0
    return num(100 - 100 / (1 + gain / loss))


def get_fundamentals(sym):
    return cached(FUND_CACHE, sym, 6 * 3600, lambda: yf.Ticker(sym).info or {}, {})


def _parse_news(raw):
    out = []
    for n in raw or []:
        if not isinstance(n, dict):
            continue
        c = n.get("content") if isinstance(n.get("content"), dict) else n
        title = c.get("title")
        if not title:
            continue
        ts = num(n.get("providerPublishTime"))
        if not ts and c.get("pubDate"):
            try:
                ts = datetime.fromisoformat(c["pubDate"].replace("Z", "+00:00")).timestamp()
            except Exception:
                ts = None
        prov = c.get("provider")
        publisher = prov.get("displayName") if isinstance(prov, dict) else n.get("publisher")
        def news_url(v):
            return v.get("url") if isinstance(v, dict) else v if isinstance(v, str) else ""
        link = n.get("link") or news_url(c.get("canonicalUrl")) or news_url(c.get("clickThroughUrl"))
        if urlparse(str(link or "")).scheme not in ("http", "https"):
            link = ""
        out.append({"title": title, "publisher": publisher or "", "link": link or "", "ts": ts})
    out.sort(key=lambda x: x["ts"] or 0, reverse=True)
    return out


def get_news(sym):
    return cached(NEWS_CACHE, sym, NEWS_REFRESH, lambda: _parse_news(yf.Ticker(sym).get_news(count=12)), [])


def news_loop():
    global WATCHLIST_NEWS
    pool = concurrent.futures.ThreadPoolExecutor(max_workers=3, thread_name_prefix="news")
    pending, due = {}, {}
    while True:
        with LOCK:
            wanted = {w["symbol"] for w in CONFIG["watchlist"]}
        for sym, f in list(pending.items()):
            if not f.done():
                continue
            pending.pop(sym)
            try:
                f.result()
            except Exception as e:
                with LOCK:
                    NEWS_STATUS["error"] = str(e)[:160]
            due[sym] = time.monotonic() + NEWS_REFRESH
        for sym in wanted:
            if sym not in pending and time.monotonic() >= due.get(sym, 0):
                pending[sym] = pool.submit(get_news, sym)
        merged, checks, errors = {}, [], []
        with CACHE_LOCK:
            for sym in wanted:
                hit = NEWS_CACHE.get(sym)
                err = CACHE_ERRORS.get((id(NEWS_CACHE), sym))
                if err:
                    errors.append(sym)
                if not hit:
                    continue
                if not err:
                    checks.append(hit[0])
                for item in hit[1]:
                    key = item.get("link") or item["title"].casefold()
                    if key not in merged:
                        merged[key] = dict(item, symbols=[])
                    merged[key]["symbols"].append(sym)
        with LOCK:
            WATCHLIST_NEWS = sorted(merged.values(), key=lambda n: n.get("ts") or 0, reverse=True)[:12]
            NEWS_STATUS.update(last_check=max(checks) if checks else None,
                               error=("Fetch failed: " + ", ".join(sorted(errors))) if errors else None,
                               covered=len(checks), total=len(wanted))
        NEWS_WAKE.wait(0.5)
        NEWS_WAKE.clear()


def _earnings_date(sym):
    cal = yf.Ticker(sym).calendar
    dates = []
    if isinstance(cal, dict):
        v = cal.get("Earnings Date")
        dates = v if isinstance(v, list) else ([v] if v else [])
    today = date.today()
    future = []
    for d in dates:
        if isinstance(d, datetime):
            d = d.date()
        if isinstance(d, date) and d >= today:
            future.append(d)
    return min(future) if future else None


def get_earnings_date(sym):
    return cached(CAL_CACHE, sym, 12 * 3600, lambda: _earnings_date(sym), None)


def _yahoo_screen(name):
    try:
        res = yf.screen(name, count=100)
    except TypeError:
        res = yf.screen(name)
    return [q["symbol"] for q in (res or {}).get("quotes", []) if q.get("symbol")]


def resolve_universe(s):
    key = s.get("universe") or "preset:us_momentum"
    market, label, syms = UNIVERSES.get(key, UNIVERSES["preset:us_momentum"])
    if key == "custom":
        raw = (s.get("custom_symbols") or "").replace("\n", ",").replace(" ", ",")
        syms = [x.strip().upper() for x in raw.split(",") if x.strip()]
    elif key == "local:watchlist":
        with LOCK:
            syms = [w["symbol"] for w in CONFIG["watchlist"]]
    elif key.startswith("yahoo:"):
        syms = cached(UNIVERSE_CACHE, key, 600, lambda: _yahoo_screen(key.split(":", 1)[1]), [])
        if not syms:
            raise ValueError(f"{label} unavailable; retry or choose a preset universe")


    return list(dict.fromkeys(syms))[:250], label


def _ge(val, th):
    return th is None or (val is not None and val >= th)


def _le(val, th):
    return th is None or (val is not None and val <= th)


def scan_symbol(sym, s):
    t = yf.Ticker(sym)
    h = cached(HISTORY_DAILY_CACHE, sym, 60, lambda: t.history(period="1y", interval="1d", timeout=HISTORY_TIMEOUT, raise_errors=True), None)
    with CACHE_LOCK:
        daily_error = CACHE_ERRORS.get((id(HISTORY_DAILY_CACHE), sym))
    if daily_error:
        raise ValueError(f"Daily data unavailable for {sym}: {daily_error}")
    if h is None or h.empty:
        raise ValueError(f"No daily data for {sym}")
    h = h.dropna(subset=["Close"])
    if len(h) < 2:
        return None
    h = h.copy()
    with LOCK:
        live = dict(QUOTES.get(sym) or {})
    if live.get("ok") and not live.get("error") and time.time() - (live.get("market_time") or 0) < 120:
        session = datetime.fromtimestamp(live["market_time"], ZoneInfo(str(h.index.tz or "UTC"))).date()
        if session == h.index[-1].date():
            h.loc[h.index[-1], "Close"] = live["price"]
            if live.get("volume") is not None:
                h.loc[h.index[-1], "Volume"] = live["volume"]
            h.loc[h.index[-1], "High"] = max(float(h["High"].iloc[-1]), live["price"])
            h.loc[h.index[-1], "Low"] = min(float(h["Low"].iloc[-1]), live["price"])
    close = h["Close"]
    price, prev = float(close.iloc[-1]), float(close.iloc[-2])
    if prev <= 0:
        return None
    pct = (price - prev) / prev * 100
    op = num(h["Open"].iloc[-1])
    gap = (op - prev) / prev * 100 if op else 0.0
    vol = num(h["Volume"].iloc[-1]) or 0.0
    avg_vol = num(h["Volume"].iloc[-21:-1].mean()) if len(h) >= 21 else None
    rel_vol = vol / avg_vol if avg_vol else None
    sma50 = num(close.rolling(50).mean().iloc[-1]) if len(close) >= 50 else None
    sma200 = num(close.rolling(200).mean().iloc[-1]) if len(close) >= 200 else None
    r = rsi(close)
    hi52 = num(h["High"].max())
    from_high = (hi52 - price) / hi52 * 100 if hi52 else None

    # --- technical / price filters (cheap) ---
    d = s.get("direction", "any")
    if d == "up" and pct <= 0:
        return None
    if d == "down" and pct >= 0:
        return None
    checks = [
        _ge(abs(pct), s.get("change_min")), _ge(abs(gap), s.get("gap_min")),
        _ge(price, s.get("price_min")), _le(price, s.get("price_max")),
        _ge(vol, s.get("volume_min")), _ge(rel_vol, s.get("rel_volume_min")),
        _ge(r, s.get("rsi_min")), _le(r, s.get("rsi_max")),
        _le(from_high, s.get("near_high_pct")),
    ]
    if not all(checks):
        return None
    if s.get("above_sma50") and not (sma50 and price > sma50):
        return None
    if s.get("above_sma200") and not (sma200 and price > sma200):
        return None

    # --- fundamentals (cached) ---
    info = get_fundamentals(sym) or {}
    fundamental_keys = ("mcap_min_b", "mcap_max_b", "pe_min", "pe_max", "eps_min", "eps_growth_min", "div_yield_min")
    needs_fundamentals = any(s.get(k) is not None for k in fundamental_keys) or s.get("sector") or s.get("rating", "any") != "any"
    with CACHE_LOCK:
        fetch_error = CACHE_ERRORS.get((id(FUND_CACHE), sym))
    if needs_fundamentals and fetch_error:
        raise ValueError(f"Fundamentals unavailable for {sym}: {fetch_error}")
    mcap = num(info.get("marketCap"))
    mcap_b = mcap / 1e9 if mcap else None
    pe = num(info.get("trailingPE"))
    eps = num(info.get("trailingEps"))
    eg = num(info.get("earningsQuarterlyGrowth"))
    eg = eg * 100 if eg is not None else None
    dy = num(info.get("trailingAnnualDividendYield"))
    dy = dy * 100 if dy is not None else num(info.get("dividendYield"))
    sector = info.get("sector") or ""
    rating = info.get("recommendationKey") or ""
    tgt = num(info.get("targetMeanPrice"))
    upside = (tgt - price) / price * 100 if tgt else None

    checks = [
        _ge(mcap_b, s.get("mcap_min_b")), _le(mcap_b, s.get("mcap_max_b")),
        _ge(pe, s.get("pe_min")), _le(pe, s.get("pe_max")),
        _ge(eps, s.get("eps_min")), _ge(eg, s.get("eps_growth_min")),
        _ge(dy, s.get("div_yield_min")),
    ]
    if not all(checks):
        return None
    if s.get("sector") and s["sector"].lower() not in sector.lower():
        return None
    rf = s.get("rating", "any")
    if rf == "buy" and rating not in ("buy", "strong_buy"):
        return None
    if rf == "strong_buy" and rating != "strong_buy":
        return None

    # --- news & events ---
    news = None
    if s.get("news_hours") is not None or s.get("news_keyword"):
        items = get_news(sym)
        with CACHE_LOCK:
            news_error = CACHE_ERRORS.get((id(NEWS_CACHE), sym))
        if news_error:
            raise ValueError(f"News unavailable for {sym}")
        if s.get("news_hours") is not None:
            cutoff = time.time() - s["news_hours"] * 3600
            items = [n for n in items if n["ts"] and n["ts"] >= cutoff]
        if s.get("news_keyword"):
            kw = s["news_keyword"].lower()
            items = [n for n in items if kw in n["title"].lower()]
        if not items:
            return None
        news = items[0]
    earn = None
    if s.get("earnings_days") is not None:
        ed = get_earnings_date(sym)
        if ed is None or not (0 <= (ed - date.today()).days <= s["earnings_days"]):
            return None
        earn = str(ed)

    return {
        "symbol": sym, "name": info.get("shortName") or info.get("longName") or sym,
        "price": price, "pct": pct, "gap": gap, "volume": vol, "rel_volume": rel_vol,
        "rsi": r, "sma50": sma50, "sma200": sma200, "from_high": from_high,
        "mcap": mcap, "pe": pe, "eps": eps, "eps_growth": eg, "div_yield": dy,
        "sector": sector, "rating": rating, "upside": upside, "earnings": earn,
        "checked_at": time.time(), "session": str(h.index[-1].date()),
        "news": news, "spark": downsample([float(x) for x in close.iloc[-30:]], 30),
    }


SORTS = {
    "abs_change": lambda r: abs(r["pct"]),
    "change": lambda r: r["pct"],
    "rel_volume": lambda r: r["rel_volume"] or 0,
    "volume": lambda r: r["volume"] or 0,
    "rsi": lambda r: r["rsi"] or 0,
    "mcap": lambda r: r["mcap"] or 0,
    "gap": lambda r: abs(r["gap"]),
    "upside": lambda r: r["upside"] if r["upside"] is not None else -1e9,
}


def run_scan(s, stop, blocking=True):
    while not SCAN_LOCK.acquire(timeout=0.1):
        if not blocking or stop.is_set():
            return
    if stop.is_set():
        SCAN_LOCK.release()
        return
    global SCREENER_RESULTS
    t0 = time.time()
    with LOCK:
        revision = SCR_REVISION
        SCREENER_STATUS.update(scanning=True, progress=0, total=0, error=None,
                               next_scan=None, failed=0, phase="resolving")
    try:
        syms, label = resolve_universe(s)
        with LOCK:
            SCREENER_STATUS.update(scanning=True, progress=0, total=len(syms),
                                   universe_label=label, error=None, phase="screening")
        if not syms:
            raise ValueError("Universe is empty; add symbols first")
        results, errors = [], []
        ex = SCREEN_POOL
        try:
            futs = [ex.submit(scan_symbol, sym, s) for sym in syms]
            pending = set(futs)
            while pending and not stop.is_set():
                done, pending = concurrent.futures.wait(pending, timeout=0.25,
                                                       return_when=concurrent.futures.FIRST_COMPLETED)
                for f in done:
                    try:
                        r = f.result()
                        if r:
                            results.append(r)
                    except Exception as e:
                        errors.append(str(e))
                    with LOCK:
                        SCREENER_STATUS.update(progress=SCREENER_STATUS["progress"] + 1, failed=len(errors))
                if time.time() - t0 > 120:
                    raise TimeoutError("Scan timed out; previous results retained")
        finally:
            for f in futs:
                f.cancel()
        if stop.is_set():
            return

        if len(errors) == len(syms):
            raise ValueError("All symbols failed: " + errors[0])
        results.sort(key=SORTS.get(s.get("sort_by"), SORTS["abs_change"]), reverse=True)
        results = results[:int(s.get("max_results") or 50)]

        with LOCK:
            SCREENER_STATUS["phase"] = "headlines"
        if s.get("show_headlines"):
            need = [r for r in results if not r["news"]]
            pending = {HEADLINE_POOL.submit(get_news, r["symbol"]): r for r in need}
            try:
                while pending and not stop.is_set():
                    done, _ = concurrent.futures.wait(pending, timeout=0.25,
                                                     return_when=concurrent.futures.FIRST_COMPLETED)
                    for future in done:
                        row = pending.pop(future)
                        items = future.result()
                        row["news"] = items[0] if items else None
                    if time.time() - t0 > 120:
                        raise TimeoutError("Headline fetch timed out; previous scan retained")
            finally:
                for future in pending:
                    future.cancel()

        if stop.is_set():
            return
        today = time.strftime("%Y-%m-%d")
        new_hits = []
        with LOCK:
            if stop.is_set() or revision != SCR_REVISION:
                SCREENER_STATUS["error"] = "Settings changed; rescan requested"
                return
            SCREENER_RESULTS = results
            SCREENER_STATUS.update(last_scan=time.time(), duration=time.time() - t0,
                                   matched=len(results), error=(f"{len(errors)} symbols failed; results are partial" if errors else None))
            if SCREENER_ANNOUNCED["day"] != today:
                SCREENER_ANNOUNCED.update(day=today, symbols=set())
            for r in results:
                if r["symbol"] not in SCREENER_ANNOUNCED["symbols"]:
                    SCREENER_ANNOUNCED["symbols"].add(r["symbol"])
                    new_hits.append(r)
            if s.get("push_to_display"):
                for r in new_hits[:3]:
                    ALERT_DISPLAY_QUEUE.append({
                        "symbol": r["symbol"], "name": r["name"], "target_price": r["price"],
                        "current_price": r["price"], "condition": None,
                        "message": f"SCREENER {r['pct']:+.1f}% MOVE"})
        if new_hits and s.get("push_to_display"):
            DEVICE_WAKE.set()
        for r in new_hits[:5]:
            log_event("screener", f"New match {r['symbol']} {r['pct']:+.2f}% @ {r['price']:,.2f}")
        if len(new_hits) > 5:
            log_event("screener", f"+{len(new_hits) - 5} more new matches")
    except Exception as e:
        with LOCK:
            SCREENER_STATUS["error"] = str(e)
        log_event("screener", f"Scan failed: {e}")
    finally:
        with LOCK:
            SCREENER_STATUS.update(scanning=False, phase="idle")
        SCAN_LOCK.release()


def screener_loop(stop, wake):
    while not stop.is_set():
        with LOCK:
            s = dict(CONFIG["screener"])
        run_scan(s, stop)
        if stop.is_set():
            break
        with LOCK:
            s = dict(CONFIG["screener"])
        interval = max(30, int(s.get("scan_interval") or 180))
        with LOCK:
            if stop.is_set():
                break
            SCREENER_STATUS["next_scan"] = time.time() + interval
        wake.wait(interval)
        wake.clear()
    with LOCK:
        if stop is SCR_STOP:
            SCREENER_STATUS["next_scan"] = None


def start_screener():
    global SCR_THREAD, SCR_STOP, SCR_WAKE
    stop_screener()
    SCR_STOP, SCR_WAKE = threading.Event(), threading.Event()
    SCR_THREAD = threading.Thread(target=screener_loop, args=(SCR_STOP, SCR_WAKE), daemon=True)
    SCR_THREAD.start()


def stop_screener():
    SCR_STOP.set()
    SCR_WAKE.set()
    with LOCK:
        SCREENER_STATUS["next_scan"] = None
    if SCR_THREAD and SCR_THREAD.is_alive():
        SCR_THREAD.join(timeout=2)


SCR_NUM_KEYS = ["change_min", "gap_min", "price_min", "price_max", "near_high_pct", "volume_min",
                "rel_volume_min", "mcap_min_b", "mcap_max_b", "pe_min", "pe_max", "eps_min",
                "eps_growth_min", "div_yield_min", "rsi_min", "rsi_max", "news_hours",
                "earnings_days", "scan_interval", "max_results"]
SCR_BOOL_KEYS = ["above_sma50", "above_sma200", "show_headlines", "push_to_display"]
SCR_STR_KEYS = ["universe", "custom_symbols", "direction", "sector", "news_keyword", "sort_by", "rating"]


def clean_screener_settings(data, current):
    out = dict(current)
    for k in SCR_NUM_KEYS:
        if k in data:
            v = data[k]
            out[k] = None if v in (None, "") else num(v)
            if v not in (None, "") and out[k] is None:
                raise ValueError(f"{k} must be a finite number")
    for k in SCR_BOOL_KEYS:
        if k in data:
            if not isinstance(data[k], bool):
                raise ValueError(f"{k} must be true or false")
            out[k] = data[k]
    for k in SCR_STR_KEYS:
        if k in data and data[k] is not None:
            out[k] = str(data[k]).strip()
    if out.get("universe") not in UNIVERSES:
        out["universe"] = "preset:us_momentum"
    if out.get("sort_by") not in SORTS:
        out["sort_by"] = "abs_change"
    out["scan_interval"] = max(30, int(out.get("scan_interval") or 180))
    out["max_results"] = min(200, max(5, int(out.get("max_results") or 50)))
    for low, high in [("price_min", "price_max"), ("mcap_min_b", "mcap_max_b"),
                      ("pe_min", "pe_max"), ("rsi_min", "rsi_max")]:
        if out.get(low) is not None and out.get(high) is not None and out[low] > out[high]:
            raise ValueError(f"{low} cannot exceed {high}")
    for key in ("rsi_min", "rsi_max"):
        if out.get(key) is not None and not 0 <= out[key] <= 100:
            raise ValueError("RSI must be between 0 and 100")
    for key in ("change_min", "gap_min", "volume_min", "rel_volume_min", "news_hours", "earnings_days", "near_high_pct"):
        if out.get(key) is not None and out[key] < 0:
            raise ValueError(f"{key} cannot be negative")
    if out.get("direction") not in ("any", "up", "down") or out.get("rating") not in ("any", "buy", "strong_buy"):
        raise ValueError("Invalid direction or rating")
    return out

# ---------------------------------------------------------------------------
# API ROUTES
# ---------------------------------------------------------------------------

def body():
    data = request.get_json(silent=True)
    if data is not None and not isinstance(data, dict):
        raise ValueError("JSON body must be an object")
    return data or {}


@app.errorhandler(ValueError)
def bad_input(error):
    return jsonify({"error": str(error)}), 400


@app.after_request
def no_api_cache(response):
    if request.path.startswith("/api/"):
        response.headers["Cache-Control"] = "no-store"
    return response


@app.route("/")
def index():
    return Response(HTML_TEMPLATE, mimetype="text/html")


@app.route("/api/state")
def api_state():
    with LOCK:
        disp = dict(CONFIG["display"])
        wl = [annotate(quote_state(dict(QUOTES.get(w["symbol"]) or empty_quote(w["symbol"]), name=w["name"])), disp)
              for w in CONFIG["watchlist"]]
        alerts = [dict(a, current=(QUOTES.get(a["symbol"]) or {}).get("price")) for a in CONFIG["alerts"]]
        device = device_snapshot()
        plan = [{"label": lbl, "symbols": [q["symbol"] for q in pg]} for lbl, pg in PageScheduler.plan(wl, disp)]
        scr = dict(SCREENER_STATUS, enabled=CONFIG["screener"]["enabled"])
        hits = [{k: r[k] for k in ("symbol", "name", "price", "pct", "rel_volume", "rsi")}
                for r in SCREENER_RESULTS[:20]]
        return jsonify({
            "watchlist": wl, "selected": CONFIG.get("selected"), "display": disp,
            "alerts": alerts, "device": device, "plan": plan, "events": list(EVENTS)[:80],
            "screener": scr, "screener_hits": hits, "server_time": time.time(),
            "selected_quote": quote_state(QUOTES.get(CONFIG.get("selected")) or empty_quote(CONFIG.get("selected"))),
            "feed": dict(FEED), "news": copy.deepcopy(WATCHLIST_NEWS), "news_status": dict(NEWS_STATUS),
        })


@app.route("/api/search")
def api_search():
    q = request.args.get("q", "").strip()
    if not q:
        return jsonify([])
    try:
        r = requests.get("https://query2.finance.yahoo.com/v1/finance/search",
                         params={"q": q, "quotesCount": 8, "newsCount": 0},
                         headers={"User-Agent": "Mozilla/5.0"}, timeout=4)
        out = []
        for item in r.json().get("quotes", []):
            if item.get("symbol"):
                out.append({"symbol": item["symbol"],
                            "name": item.get("shortname") or item.get("longname") or item["symbol"],
                            "exchange": item.get("exchDisp", ""), "type": item.get("typeDisp", "")})
        return jsonify(out[:8])
    except Exception as e:
        print(f"Search error: {e}")
        return jsonify([])


@app.route("/api/quote")
def api_quote():
    sym = request.args.get("symbol", "").strip()
    if not sym:
        return jsonify({}), 400
    with LOCK:
        q = dict(QUOTES[sym]) if sym in QUOTES else None
    if q is None:
        q = cached(QUOTE_CACHE, sym, 20, lambda: fetch_quote(sym), None) or empty_quote(sym)
        q = dict(q)
    q["detail"] = cached(DETAIL_CACHE, sym, 60, lambda: get_detail(sym), {})
    return jsonify(q)


@app.route("/api/price")
def api_price():
    sym = request.args.get("symbol", "").strip()
    return jsonify({"symbol": sym, "price": get_live_price(sym) if sym else 0.0})


@app.route("/api/history")
def api_history():
    sym = request.args.get("symbol", "").strip()
    rng = request.args.get("range", "1D")
    if not sym or rng not in HIST_RANGES:
        return jsonify({"bars": []}), 400
    bars = cached(HISTORY_CACHE, (sym, rng), HIST_RANGES[rng][3], lambda: get_history(sym, rng), [])
    prev = None
    if rng == "1D":
        with LOCK:
            prev = (QUOTES.get(sym) or {}).get("prev_close")
        if prev is None:
            q = cached(QUOTE_CACHE, sym, 20, lambda: fetch_quote(sym), None)
            prev = q.get("prev_close") if q else None
    bars = merge_live_history(sym, rng, bars)
    with CACHE_LOCK:
        error = CACHE_ERRORS.get((id(HISTORY_CACHE), (sym, rng)))
    return jsonify({"symbol": sym, "range": rng, "bars": bars, "prev_close": prev, "error": error})


@app.route("/api/select", methods=["POST"])
def api_select():
    sym = str(body().get("symbol", "")).strip()
    if sym:
        with LOCK:
            CONFIG["selected"] = sym
            save_config()
        MARKET_WAKE.set()
    return jsonify({"ok": True})


@app.route("/api/watchlist/add", methods=["POST"])
def api_wl_add():
    d = body()
    sym = str(d.get("symbol", "")).strip().upper()
    name = str(d.get("name") or sym).strip()[:40]
    if not sym:
        return jsonify({"error": "Symbol required"}), 400
    with LOCK:
        if any(w["symbol"] == sym for w in CONFIG["watchlist"]):
            return jsonify({"error": f"{sym} already in watchlist"}), 400
        if len(CONFIG["watchlist"]) >= MAX_WATCHLIST:
            return jsonify({"error": f"Watchlist limit is {MAX_WATCHLIST}"}), 400
        CONFIG["watchlist"].append({"symbol": sym, "name": name})
        save_config()
    MARKET_WAKE.set()
    NEWS_WAKE.set()
    DEVICE_WAKE.set()
    log_event("system", f"Added {sym} to watchlist")
    return jsonify({"ok": True})


@app.route("/api/watchlist/remove", methods=["POST"])
def api_wl_remove():
    sym = str(body().get("symbol", "")).strip()
    with LOCK:
        CONFIG["watchlist"] = [w for w in CONFIG["watchlist"] if w["symbol"] != sym]
        save_config()
    MARKET_WAKE.set()
    NEWS_WAKE.set()
    DEVICE_WAKE.set()
    log_event("system", f"Removed {sym} from watchlist")
    return jsonify({"ok": True})


@app.route("/api/watchlist/move", methods=["POST"])
def api_wl_move():
    d = body()
    sym, step = str(d.get("symbol", "")), int(d.get("dir", 0))
    with LOCK:
        wl = CONFIG["watchlist"]
        idx = next((i for i, w in enumerate(wl) if w["symbol"] == sym), None)
        if idx is not None and 0 <= idx + step < len(wl):
            wl[idx], wl[idx + step] = wl[idx + step], wl[idx]
            save_config()
    return jsonify({"ok": True})


@app.route("/api/watchlist/rename", methods=["POST"])
def api_wl_rename():
    d = body()
    sym, name = str(d.get("symbol", "")), str(d.get("name", "")).strip()[:40]
    with LOCK:
        for w in CONFIG["watchlist"]:
            if w["symbol"] == sym and name:
                w["name"] = name
        save_config()
    return jsonify({"ok": True})


@app.route("/api/alerts", methods=["GET", "POST"])
def api_alerts():
    if request.method == "GET":
        with LOCK:
            return jsonify(list(CONFIG["alerts"]))
    d = body()
    sym = str(d.get("symbol", "")).strip()
    target = num(d.get("target_price"))
    if not sym or not target or target <= 0:
        return jsonify({"error": "Symbol and positive target required"}), 400
    base = num(d.get("base_price")) or 0
    if base <= 0:
        base = get_live_price(sym)
    if base <= 0:
        return jsonify({"error": "Market price unavailable"}), 400
    a = {"id": uuid.uuid4().hex[:8], "symbol": sym, "name": str(d.get("name") or sym)[:40],
         "base_price": base, "target_price": target, "condition": ">=" if target >= base else "<=",
         "note": str(d.get("note") or "")[:80], "created": time.time(),
         "triggered": False, "triggered_at": None, "triggered_price": None}
    with LOCK:
        CONFIG["alerts"].append(a)
        save_config()
    MARKET_WAKE.set()
    log_event("alert", f"Alert armed: {sym} {a['condition']} {target:,.2f}")
    return jsonify(a), 201


@app.route("/api/alerts/delete", methods=["POST"])
def api_alert_delete():
    aid = str(body().get("id", ""))
    with LOCK:
        CONFIG["alerts"] = [a for a in CONFIG["alerts"] if a["id"] != aid]
        save_config()
    return jsonify({"ok": True})


@app.route("/api/alerts/rearm", methods=["POST"])
def api_alert_rearm():
    aid = str(body().get("id", ""))
    with LOCK:
        for a in CONFIG["alerts"]:
            if a["id"] == aid:
                price = (QUOTES.get(a["symbol"]) or {}).get("price") or a["base_price"]
                a.update(triggered=False, triggered_at=None, triggered_price=None, base_price=price,
                         condition=">=" if a["target_price"] >= price else "<=")
        save_config()
    MARKET_WAKE.set()
    return jsonify({"ok": True})


@app.route("/api/device", methods=["POST"])
def api_device():
    d = body()
    with LOCK:
        if d.get("ip"):
            candidate = str(d["ip"]).strip()
            address = ipaddress.ip_address(candidate)
            if address.version != 4:
                raise ValueError("Use the device IPv4 address")
            if CONFIG["ip"] != candidate:
                DEVICE.update(last_push=None, confirmed_ip=None, error=None, symbols=[])
            CONFIG["ip"] = candidate
        if "running" in d:
            if not isinstance(d["running"], bool):
                raise ValueError("running must be true or false")
            if CONFIG["device_running"] != d["running"]:
                DEVICE.update(last_push=None, confirmed_ip=None, error=None, symbols=[])
            CONFIG["device_running"] = d["running"]
        disp = CONFIG["display"]
        for k, lo, hi in [("page_seconds", 3, 60), ("alert_seconds", 3, 30),
                          ("mover_pct", 0.1, 50), ("momentum_pct", 0.05, 20)]:
            if k in d and num(d[k]) is not None:
                disp[k] = min(hi, max(lo, num(d[k])))
        save_config()
        running = CONFIG["device_running"]
        ip = CONFIG["ip"]
    if "running" in d:
        log_event("device", f"Streaming {'started' if running else 'stopped'} ({ip})")
    DEVICE_WAKE.set()
    return jsonify({"ok": True, "running": running})


@app.route("/api/device/push", methods=["POST"])
def api_device_push():
    with LOCK:
        if not CONFIG["device_running"]:
            return jsonify({"error": "Start the device before pushing a screen"}), 409
        DEVICE["last_push"] = None
    DEVICE_WAKE.set()
    return jsonify({"ok": True})


@app.route("/api/preview.jpg")
def api_preview():
    with LOCK:
        data = PREVIEW["bytes"]
    if not data:
        data = to_jpeg(render_page([], "STARTING"))
    return Response(data, mimetype="image/jpeg", headers={"Cache-Control": "no-store"})


@app.route("/api/screener")
def api_screener():
    with LOCK:
        return jsonify({
            "settings": dict(CONFIG["screener"]),
            "universes": [{"key": k, "market": v[0], "label": v[1]} for k, v in UNIVERSES.items()],
            "status": dict(SCREENER_STATUS, enabled=CONFIG["screener"]["enabled"]),
            "results": list(SCREENER_RESULTS),
        })


@app.route("/api/screener/settings", methods=["POST"])
def api_screener_settings():
    global SCR_REVISION
    with LOCK:
        CONFIG["screener"] = clean_screener_settings(body(), CONFIG["screener"])
        SCR_REVISION += 1
        save_config()
    SCR_WAKE.set()
    return jsonify({"ok": True})


@app.route("/api/screener/toggle", methods=["POST"])
def api_screener_toggle():
    with SCR_CONTROL:
        with LOCK:
            CONFIG["screener"]["enabled"] = not CONFIG["screener"]["enabled"]
            enabled = CONFIG["screener"]["enabled"]
            save_config()
        if enabled:
            start_screener()
        else:
            stop_screener()
    log_event("screener", f"Screener engine {'enabled' if enabled else 'disabled'}")
    return jsonify({"enabled": enabled})



@app.route("/api/screener/scan", methods=["POST"])
def api_screener_scan():
    global SCR_REQUESTED
    with LOCK:
        if CONFIG["screener"]["enabled"] and SCR_THREAD and SCR_THREAD.is_alive():
            SCR_WAKE.set()
            return jsonify({"ok": True, "note": "scan requested"})
        if SCR_REQUESTED:
            return jsonify({"ok": True, "note": "scan already queued"})
        SCR_REQUESTED = True
    def requested_scan():
        global SCR_REQUESTED
        try:
            # Wait outside run_scan so the latest saved filter revision is used.
            with SCAN_LOCK:
                pass
            with LOCK:
                settings = dict(CONFIG["screener"])
            run_scan(settings, threading.Event(), False)
        finally:
            with LOCK:
                SCR_REQUESTED = False
    threading.Thread(target=requested_scan, daemon=True).start()
    return jsonify({"ok": True, "note": "scan queued"})

# ---------------------------------------------------------------------------
# WEB UI
# ---------------------------------------------------------------------------

HTML_TEMPLATE = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>SkyLoong Terminal</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
<script src="https://unpkg.com/lightweight-charts@4.1.3/dist/lightweight-charts.standalone.production.js"></script>
<style>
:root{--bg:#070b19;--bg2:#0a1022;--panel:#0f1630;--panel2:#141c3a;--line:#1d2749;--line2:#2a3663;--text:#e7eaf6;--muted:#7d88ad;--dim:#56608a;--acc:#6d5dfc;--acc2:#8b7dff;--cyan:#22d3ee;--up:#2ed3a0;--dn:#f0506e;--warn:#ffb547;--r:14px}
*{box-sizing:border-box}
html,body{margin:0;min-height:100vh;background:radial-gradient(1200px 600px at 15% -10%,#17224f 0%,transparent 60%),radial-gradient(900px 500px at 100% 0%,#1a1440 0%,transparent 55%),var(--bg);color:var(--text);font-family:Inter,system-ui,sans-serif;font-size:13px}
.mono{font-family:'JetBrains Mono',ui-monospace,Consolas,monospace;font-variant-numeric:tabular-nums}
::-webkit-scrollbar{width:8px;height:8px}::-webkit-scrollbar-thumb{background:#243061;border-radius:8px}::-webkit-scrollbar-track{background:transparent}
.nav{position:sticky;top:0;z-index:60;display:flex;align-items:center;gap:28px;height:60px;padding:0 24px;background:rgba(8,12,28,.82);backdrop-filter:blur(14px);border-bottom:1px solid var(--line)}
.brand{display:flex;align-items:center;gap:10px;font-size:17px;font-weight:600;letter-spacing:.2px;white-space:nowrap}
.brand .logo{width:28px;height:28px;border-radius:8px;background:linear-gradient(135deg,var(--acc),var(--cyan));display:grid;place-items:center;font-weight:800;font-size:13px;box-shadow:0 0 18px rgba(109,93,252,.5)}
.brand b{color:var(--acc2);font-weight:600}
.tabs{display:flex;height:100%}
.tabs button{background:none;border:0;border-bottom:2px solid transparent;color:var(--muted);font:inherit;font-weight:500;padding:0 18px;cursor:pointer;height:100%;transition:.15s}
.tabs button:hover{color:var(--text)}
.tabs button.active{color:var(--text);border-bottom-color:var(--acc);background:linear-gradient(180deg,transparent,rgba(109,93,252,.14))}
.nav-right{margin-left:auto;display:flex;align-items:center;gap:12px}
.clock{color:var(--muted);font-size:12px}
.pill{display:inline-flex;align-items:center;gap:8px;padding:6px 12px;border-radius:999px;background:var(--panel2);border:1px solid var(--line);color:var(--muted);font-size:12px;white-space:nowrap}
.pill i{width:8px;height:8px;border-radius:50%;background:var(--dim)}
.pill.on{color:var(--up)}.pill.on i{background:var(--up);box-shadow:0 0 10px var(--up)}
.pill.err{color:var(--dn)}.pill.err i{background:var(--dn);box-shadow:0 0 10px var(--dn)}
.btn{border:1px solid var(--line2);background:var(--panel2);color:var(--text);font:inherit;font-weight:500;padding:8px 14px;border-radius:10px;cursor:pointer;transition:.15s;white-space:nowrap}
.btn:hover{border-color:var(--acc)}
.btn.primary{background:linear-gradient(135deg,var(--acc),var(--acc2));border-color:transparent;color:#fff}
.btn.primary:hover{filter:brightness(1.12)}
.btn.danger{background:rgba(240,80,110,.12);border-color:rgba(240,80,110,.45);color:var(--dn)}
.btn.ghost{background:transparent}
.btn.sm{padding:5px 10px;font-size:12px;border-radius:8px}
.btn.block{width:100%}
.icon-btn{background:none;border:0;color:var(--muted);cursor:pointer;padding:3px 5px;border-radius:6px;font-size:12px}
.icon-btn:hover{background:var(--panel2);color:var(--text)}
main{padding:20px 24px 48px;max-width:1720px;margin:0 auto}
.view{display:none}.view.active{display:block;animation:fade .25s ease}
@keyframes fade{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:none}}
.page-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;gap:16px}
.page-head h1{margin:0;font-size:24px;font-weight:600}
.page-head .sub{color:var(--muted);font-size:12px;margin-top:4px}
.seg{display:inline-flex;background:var(--panel);border:1px solid var(--line);border-radius:999px;padding:3px}
.seg button{border:0;background:none;color:var(--muted);font:inherit;padding:6px 16px;border-radius:999px;cursor:pointer}
.seg button.on{background:var(--acc);color:#fff}
.card{background:linear-gradient(180deg,var(--panel),var(--bg2));border:1px solid var(--line);border-radius:var(--r);box-shadow:0 12px 32px rgba(0,0,0,.28);min-width:0}
.card-h{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:13px 16px;border-bottom:1px solid var(--line)}
.card-h h3{margin:0;font-size:13px;font-weight:600;letter-spacing:.2px;display:flex;align-items:center;gap:8px}
.card-b{padding:14px 16px}
.count{background:var(--panel2);border:1px solid var(--line2);color:var(--muted);font-size:11px;padding:1px 8px;border-radius:999px}
.muted{color:var(--muted)}.dim{color:var(--dim)}.small{font-size:11px}
.up{color:var(--up)}.dn{color:var(--dn)}
.chip{display:inline-block;padding:3px 8px;border-radius:6px;font-weight:600;font-size:11.5px;min-width:64px;text-align:center}
.chip.up{background:rgba(46,211,160,.14);color:var(--up)}.chip.dn{background:rgba(240,80,110,.14);color:var(--dn)}.chip.na{background:var(--panel2);color:var(--dim)}
.tag{font-size:9px;font-weight:700;letter-spacing:.6px;padding:2px 6px;border-radius:4px;margin-left:6px;vertical-align:middle}
.tag.mover{background:rgba(255,181,71,.15);color:var(--warn)}
.tag.live{background:rgba(109,93,252,.22);color:var(--acc2)}
.empty{padding:26px;text-align:center;color:var(--dim)}
.strip{display:flex;align-items:stretch;margin-bottom:16px;border-top:2px solid var(--acc);overflow-x:auto}
.strip>div{padding:14px 20px;border-right:1px solid var(--line);white-space:nowrap;display:flex;flex-direction:column;justify-content:center}
.strip>div:last-child{border-right:0;margin-left:auto}
.s-id{flex-direction:row!important;align-items:center;gap:12px;min-width:220px}
.avatar{width:38px;height:38px;border-radius:50%;background:linear-gradient(135deg,var(--acc),var(--cyan));display:grid;place-items:center;font-weight:700;font-size:15px}
.s-sym{font-size:16px;font-weight:600}
.big{font-size:22px;font-weight:600}
.kv .k{font-size:11px;color:var(--muted);margin-bottom:5px}
.kv .v{font-size:14px;font-weight:500}
.range{display:flex;align-items:center;gap:8px}
.rbar{position:relative;width:110px;height:5px;border-radius:5px;background:linear-gradient(90deg,var(--dn),var(--warn),var(--up))}
.rbar i{position:absolute;top:-4px;width:3px;height:13px;border-radius:2px;background:#fff;box-shadow:0 0 6px #fff;transform:translateX(-1px)}
.s-act{flex-direction:row!important;align-items:center;gap:8px}
.grid-dash{display:grid;grid-template-columns:350px minmax(0,1fr) 300px;gap:16px;align-items:start}
body.simple .grid-dash{grid-template-columns:350px minmax(0,1fr)}
body.simple .adv{display:none!important}
.side{display:flex;flex-direction:column;gap:16px}
@media(max-width:1350px){.grid-dash{grid-template-columns:330px minmax(0,1fr)}.side{grid-column:1/-1;display:grid;grid-template-columns:repeat(3,minmax(0,1fr))}}
@media(max-width:900px){.grid-dash{grid-template-columns:1fr}.side{grid-template-columns:1fr}}
.wl-list{max-height:590px;overflow-y:auto}
.wl-row{display:grid;grid-template-columns:minmax(0,1fr) 74px 92px;align-items:center;gap:10px;padding:10px 16px;border-bottom:1px solid var(--line);cursor:pointer;position:relative;transition:background .12s}
.wl-row:hover{background:rgba(109,93,252,.07)}
.wl-row.sel{background:linear-gradient(90deg,rgba(109,93,252,.18),transparent);box-shadow:inset 3px 0 0 var(--acc)}
.wl-row .sym{font-weight:600;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.wl-row .nm{color:var(--muted);font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:2px}
.wl-row canvas{width:74px;height:30px}
.wl-px{text-align:right}.wl-px .px{font-weight:500;margin-bottom:4px}
.wl-act{position:absolute;right:8px;top:50%;transform:translateY(-50%);display:none;gap:2px;background:var(--panel2);border:1px solid var(--line2);border-radius:8px;padding:2px}
.wl-row:hover .wl-act{display:flex}
.wl-add{padding:12px 16px;border-bottom:1px solid var(--line);display:none;position:relative}
.wl-add.open{display:block}
.srch{position:relative}
.dd{position:absolute;left:0;right:0;top:calc(100% + 4px);background:#0d1430;border:1px solid var(--line2);border-radius:10px;z-index:80;max-height:260px;overflow-y:auto;display:none;box-shadow:0 18px 40px rgba(0,0,0,.55)}
.dd .it{padding:9px 12px;cursor:pointer;display:flex;justify-content:space-between;gap:10px;border-bottom:1px solid var(--line)}
.dd .it:hover{background:rgba(109,93,252,.16)}
.dd .it b{font-weight:600}.dd .it span{color:var(--muted);font-size:11px;text-align:right}
.chart-tools{display:flex;align-items:center;gap:6px;flex-wrap:wrap}
.tf{display:flex;gap:4px}
.tf button{background:none;border:1px solid transparent;color:var(--muted);font:inherit;font-size:12px;padding:5px 10px;border-radius:8px;cursor:pointer}
.tf button:hover{color:var(--text)}
.tf button.on{background:var(--acc);color:#fff}
.chart-wrap{position:relative;height:440px}
#chart{position:absolute;inset:0}
.legend{position:absolute;left:14px;top:10px;z-index:5;font-size:11.5px;color:var(--muted);pointer-events:none;display:flex;gap:12px;flex-wrap:wrap}
.legend b{color:var(--text);font-weight:500}
.chart-msg{position:absolute;inset:0;display:none;place-items:center;color:var(--dim);z-index:4}
.mv-row{display:grid;grid-template-columns:70px 1fr 62px;align-items:center;gap:8px;padding:6px 0;cursor:pointer}
.mv-bar{height:6px;border-radius:6px;background:var(--panel2);overflow:hidden}
.mv-bar i{display:block;height:100%;border-radius:6px}
.preview{width:100%;aspect-ratio:4/3;border-radius:10px;border:1px solid var(--line2);background:#000;display:block}
.breadth{display:flex;height:8px;border-radius:8px;overflow:hidden;background:var(--panel2);margin:10px 0}
.breadth .a{background:var(--up)}.breadth .d{background:var(--dn)}
.stat3{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;text-align:center}
.stat3 .v{font-size:18px;font-weight:600}
.tabbar{display:flex;gap:6px}
.tabbar button{background:var(--panel2);border:1px solid var(--line2);color:var(--muted);font:inherit;font-size:12px;padding:6px 14px;border-radius:999px;cursor:pointer}
.tabbar button.on{background:var(--acc);border-color:var(--acc);color:#fff}
.tbl-wrap{overflow-x:auto}
table.tbl{width:100%;border-collapse:collapse;font-size:12.5px}
.tbl th{text-align:left;font-weight:500;font-size:10.5px;text-transform:uppercase;letter-spacing:.6px;color:var(--muted);padding:10px 12px;border-bottom:1px solid var(--line);white-space:nowrap;position:sticky;top:0;background:var(--panel);z-index:2}
.tbl th.sort{cursor:pointer}.tbl th.sort:hover{color:var(--text)}
.tbl td{padding:10px 12px;border-bottom:1px solid var(--line);white-space:nowrap}
.tbl tr:hover td{background:rgba(109,93,252,.05)}
.tbl .r{text-align:right}
.badge{display:inline-block;font-size:10.5px;font-weight:600;padding:3px 8px;border-radius:6px;border:1px solid}
.badge.armed{color:var(--acc2);border-color:rgba(139,125,255,.45);background:rgba(109,93,252,.1)}
.badge.hit{color:var(--up);border-color:rgba(46,211,160,.45);background:rgba(46,211,160,.1)}
.badge.alert{color:var(--warn);border-color:rgba(255,181,71,.4)}
.badge.screener{color:var(--acc2);border-color:rgba(139,125,255,.4)}
.badge.device{color:var(--dn);border-color:rgba(240,80,110,.4)}
.badge.system{color:var(--muted);border-color:var(--line2)}
.prog{height:5px;border-radius:5px;background:var(--panel2);overflow:hidden;min-width:90px}
.prog i{display:block;height:100%;background:linear-gradient(90deg,var(--acc),var(--cyan))}
.news{max-width:320px;overflow:hidden;text-overflow:ellipsis;color:var(--muted)}
.news a{color:var(--muted);text-decoration:none}.news a:hover{color:var(--text)}
input,select,textarea{width:100%;background:var(--bg2);border:1px solid var(--line2);color:var(--text);border-radius:9px;padding:9px 11px;font:inherit;font-size:12.5px}
textarea{resize:vertical;min-height:60px}
input:focus,select:focus,textarea:focus{outline:none;border-color:var(--acc);box-shadow:0 0 0 3px rgba(109,93,252,.2)}
input::placeholder,textarea::placeholder{color:var(--dim)}
select option,select optgroup{background:#0d1430}
.fld label{display:block;font-size:11px;color:var(--muted);margin-bottom:5px}
.fgrid{display:grid;grid-template-columns:1fr 1fr;gap:10px 12px}
.fgrid .wide{grid-column:1/-1}
.check{display:flex;align-items:center;gap:8px;font-size:12px;color:var(--text);cursor:pointer;padding:6px 0}
.check input{width:16px;height:16px;accent-color:var(--acc);margin:0}
details.grp{border-bottom:1px solid var(--line)}
details.grp>summary{list-style:none;cursor:pointer;padding:13px 16px;font-weight:600;font-size:12.5px;display:flex;justify-content:space-between;align-items:center}
details.grp>summary::-webkit-details-marker{display:none}
details.grp>summary::after{content:'+';color:var(--muted);font-size:16px}
details.grp[open]>summary::after{content:'-'}
details.grp .gb{padding:2px 16px 16px}
.presets{display:flex;gap:6px;flex-wrap:wrap;padding:12px 16px;border-bottom:1px solid var(--line)}
.presets button{background:var(--panel2);border:1px solid var(--line2);color:var(--text);font:inherit;font-size:11.5px;padding:5px 11px;border-radius:999px;cursor:pointer}
.presets button:hover{border-color:var(--acc);color:var(--acc2)}
.grid-scr,.grid-2{display:grid;grid-template-columns:380px minmax(0,1fr);gap:16px;align-items:start}
@media(max-width:1100px){.grid-scr,.grid-2{grid-template-columns:1fr}}
.scr-panel{position:sticky;top:76px;max-height:calc(100vh - 96px);display:flex;flex-direction:column}
.scr-panel .scroll{overflow-y:auto;flex:1}
.stats{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:12px;margin-bottom:16px}
@media(max-width:1100px){.stats{grid-template-columns:repeat(2,1fr)}}
.stat{padding:14px 16px}
.stat .k{font-size:11px;color:var(--muted);margin-bottom:6px}
.stat .v{font-size:18px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.switch{position:relative;width:42px;height:24px;flex:none;cursor:pointer}
.switch input{display:none}
.switch span{position:absolute;inset:0;background:var(--panel2);border:1px solid var(--line2);border-radius:999px;transition:.2s}
.switch span::after{content:'';position:absolute;top:3px;left:3px;width:16px;height:16px;border-radius:50%;background:var(--muted);transition:.2s}
.switch input:checked+span{background:rgba(46,211,160,.2);border-color:var(--up)}
.switch input:checked+span::after{left:21px;background:var(--up)}
.eng{display:flex;align-items:center;gap:10px}
.qbtns{display:flex;gap:6px;flex-wrap:wrap}
.qbtns button{flex:1;background:var(--panel2);border:1px solid var(--line2);color:var(--text);font:inherit;font-size:11.5px;padding:6px 0;border-radius:8px;cursor:pointer;min-width:48px}
.qbtns button:hover{border-color:var(--acc)}
.move{margin-top:12px;padding:12px;border-radius:10px;text-align:center;font-weight:600;border:1px solid var(--line2);background:var(--bg2)}
.move.up{border-color:rgba(46,211,160,.5);background:rgba(46,211,160,.08)}
.move.dn{border-color:rgba(240,80,110,.5);background:rgba(240,80,110,.08)}
.sel-box{display:flex;justify-content:space-between;align-items:center;margin:12px 0;padding:12px;border-radius:10px;background:var(--bg2);border:1px solid var(--line)}
.plan-row{display:flex;gap:12px;align-items:center;padding:10px 0;border-bottom:1px solid var(--line)}
.plan-row.cur .plan-l{color:var(--acc2)}
.plan-l{width:130px;font-weight:600;font-size:12px;flex:none}
.sym-chip{display:inline-block;background:var(--panel2);border:1px solid var(--line2);border-radius:6px;padding:3px 8px;margin:2px;font-size:11.5px}
.dev-grid{display:grid;grid-template-columns:380px minmax(0,1fr) 380px;gap:16px;align-items:start}
@media(max-width:1300px){.dev-grid{grid-template-columns:1fr 1fr}}
@media(max-width:900px){.dev-grid{grid-template-columns:1fr}}
.toast{position:fixed;right:22px;bottom:22px;background:var(--panel2);border:1px solid var(--acc);color:var(--text);padding:11px 16px;border-radius:10px;box-shadow:0 12px 30px rgba(0,0,0,.5);opacity:0;transform:translateY(10px);transition:.2s;z-index:100;pointer-events:none}
.toast.show{opacity:1;transform:none}.toast.err{border-color:var(--dn)}
canvas.dist{width:100%;height:150px;display:block}
</style>
</head>
<body>
<header class="nav">
  <div class="brand"><div class="logo">S</div>SkyLoong <b>Terminal</b></div>
  <nav class="tabs">
    <button data-view="dashboard" class="active">Dashboard</button>
    <button data-view="screener">Screener</button>
    <button data-view="alerts">Alerts</button>
    <button data-view="device">Device</button>
  </nav>
  <div class="nav-right">
    <span class="clock mono" id="clock"></span>
    <span class="pill" id="devPill"><i></i><span>Device offline</span></span>
    <button class="btn primary" id="devBtn">Start Device</button>
  </div>
</header>

<main>
<section class="view active" id="view-dashboard">
  <div class="page-head">
    <div><h1>Market Monitor</h1><div class="sub">Streaming watchlist with polling fallback · movers are prioritised on the SkyLoong display</div></div>
    <div class="seg" id="modeSeg"><button data-mode="simple">Simple</button><button data-mode="advanced">Advanced</button></div>
  </div>
  <div class="card strip" id="strip"></div>
  <div class="small muted" id="feedStatus" style="margin-bottom:12px">Connecting to market data…</div>
  <div class="grid-dash">
    <div class="card">
      <div class="card-h"><h3>Watchlist <span class="count" id="wlCount">0</span></h3><button class="btn sm primary" id="wlAddBtn">+ Add</button></div>
      <div class="wl-add" id="wlAdd">
        <div class="srch"><input id="wlSearch" placeholder="Search ticker or company (e.g. NVDA, Reliance, ETH)" autocomplete="off"><div class="dd" id="wlDD"></div></div>
        <div class="small dim" style="margin-top:6px">Add as many as you like. The display shows the biggest movers first, then rotates through the rest.</div>
      </div>
      <div class="wl-list" id="wlList"></div>
    </div>
    <div class="card">
      <div class="card-h">
        <h3 id="chartTitle">Chart</h3>
        <div class="chart-tools">
          <div class="tf" id="tfBtns"><button data-r="1D" class="on">1D</button><button data-r="5D">5D</button><button data-r="1M">1M</button><button data-r="6M">6M</button><button data-r="1Y">1Y</button><button data-r="5Y">5Y</button></div>
          <div class="seg" id="ctSeg" style="margin-left:6px"><button data-t="candle" class="on">Candles</button><button data-t="line">Area</button></div>
        </div>
      </div>
      <div class="chart-wrap"><div class="legend mono" id="legend"></div><div class="chart-msg" id="chartMsg">Loading...</div><div id="chart"></div></div>
    </div>
    <div class="side adv">
      <div class="card"><div class="card-h"><h3>Top Movers</h3><span class="small muted">by |day %|</span></div><div class="card-b" id="movers"></div></div>
      <div class="card"><div class="card-h"><h3>Device Screen</h3><span class="tag live" id="pvLabel">-</span></div><div class="card-b"><img class="preview" id="pvImg" alt="device preview"><div class="small muted" id="pvNext" style="margin-top:10px"></div></div></div>
      <div class="card"><div class="card-h"><h3>Watchlist Breadth</h3></div><div class="card-b" id="breadth"></div></div>
    </div>
  </div>
  <div class="card" style="margin-top:16px">
    <div class="card-h"><h3>Watchlist News</h3><span class="small muted" id="newsStatus">Loading…</span></div>
    <div id="watchNews" class="card-b" style="max-height:245px;overflow:auto"></div>
  </div>
  <div class="card" style="margin-top:16px">
    <div class="card-h">
      <div class="tabbar" id="bottomTabs"><button data-b="alerts" class="on">Price Alerts</button><button data-b="hits">Screener Hits</button><button data-b="events">Event Log</button></div>
      <span class="small muted" id="bottomInfo"></span>
    </div>
    <div class="tbl-wrap" id="bottomBody" style="max-height:340px;overflow-y:auto"></div>
  </div>
</section>

<section class="view" id="view-screener">
  <div class="page-head">
    <div><h1>Stock Screener</h1><div class="sub">Filter any market by performance, volume, fundamentals, technicals and news</div></div>
    <div class="eng">
      <span class="small muted">Auto-scan engine</span>
      <label class="switch"><input type="checkbox" id="scrEnabled"><span></span></label>
      <button class="btn primary" id="scrScanBtn">Save &amp; Scan Now</button>
    </div>
  </div>
  <div class="grid-scr">
    <div class="card scr-panel">
      <div class="card-h"><h3>Screener Settings</h3><button class="btn sm ghost" id="scrSaveBtn">Save</button></div>
      <div class="presets" id="presets">
        <button data-p="momentum">Momentum</button><button data-p="breakout">Breakout</button>
        <button data-p="oversold">Oversold</button><button data-p="value">Value</button>
        <button data-p="growth">Growth</button><button data-p="news">In the News</button>
        <button data-p="earnings">Earnings Soon</button><button data-p="clear">Clear</button>
      </div>
      <div class="scroll" id="scrForm"></div>
    </div>
    <div>
      <div class="stats">
        <div class="card stat"><div class="k">Universe</div><div class="v" id="stUni" style="font-size:14px">-</div></div>
        <div class="card stat"><div class="k">Scanned</div><div class="v mono" id="stScan">-</div></div>
        <div class="card stat"><div class="k">Matches</div><div class="v mono" id="stMatch">-</div></div>
        <div class="card stat"><div class="k">Last scan</div><div class="v" id="stLast" style="font-size:14px">-</div></div>
        <div class="card stat"><div class="k">Next scan</div><div class="v" id="stNext" style="font-size:14px">-</div></div>
      </div>
      <div class="card" style="margin-bottom:16px">
        <div class="card-h"><h3>Match Distribution <span class="small muted">(day change %)</span></h3><div style="width:220px"><div class="prog" id="scrProg" style="display:none"><i style="width:0"></i></div></div></div>
        <div class="card-b"><canvas class="dist" id="scrDist"></canvas></div>
      </div>
      <div class="card">
        <div class="card-h"><h3>Results <span class="count" id="scrCount">0</span></h3><span class="small muted">Click a column to sort · + adds to watchlist</span></div>
        <div class="tbl-wrap" style="max-height:620px;overflow-y:auto" id="scrTable"></div>
      </div>
    </div>
  </div>
</section>

<section class="view" id="view-alerts">
  <div class="page-head"><div><h1>Price Alerts</h1><div class="sub">Alerts take over the SkyLoong display when triggered · saved across restarts</div></div></div>
  <div class="grid-2">
    <div class="card">
      <div class="card-h"><h3>Create Alert</h3></div>
      <div class="card-b">
        <div class="srch"><input id="alSearch" placeholder="Search ticker (e.g. NVDA, BTC-USD)" autocomplete="off"><div class="dd" id="alDD"></div></div>
        <div class="sel-box">
          <div><div style="font-weight:600;font-size:15px" id="alSym">No ticker</div><div class="small muted" id="alName"></div></div>
          <div style="text-align:right"><div class="small muted">Market price</div><div class="mono" style="font-size:17px;font-weight:600" id="alPx">-</div></div>
        </div>
        <div class="fld"><label>Target price</label><input type="number" step="any" id="alTarget" placeholder="Enter target"></div>
        <div class="qbtns" style="margin-top:8px" id="alQuick">
          <button data-q="-10">-10%</button><button data-q="-5">-5%</button><button data-q="-2">-2%</button>
          <button data-q="2">+2%</button><button data-q="5">+5%</button><button data-q="10">+10%</button>
        </div>
        <div class="move" id="alMove">Required move: -</div>
        <div class="fld" style="margin-top:12px"><label>Note (optional)</label><input id="alNote" placeholder="e.g. breakout above resistance"></div>
        <button class="btn primary block" style="margin-top:14px" id="alCreate">Arm Alert</button>
      </div>
    </div>
    <div class="card">
      <div class="card-h"><h3>Alert Book <span class="count" id="alCount">0</span></h3></div>
      <div class="tbl-wrap" id="alTable"></div>
    </div>
  </div>
</section>

<section class="view" id="view-device">
  <div class="page-head"><div><h1>SkyLoong Display</h1><div class="sub">320x240 hardware screen · movers-first rotation</div></div></div>
  <div class="dev-grid">
    <div class="card">
      <div class="card-h"><h3>Connection &amp; Rotation</h3></div>
      <div class="card-b">
        <div class="fgrid">
          <div class="fld wide"><label>Device IP address</label><input id="dvIp"></div>
          <div class="fld"><label>Seconds per page</label><input type="number" id="dvPage" min="3" max="60"></div>
          <div class="fld"><label>Alert hold (sec)</label><input type="number" id="dvAlert" min="3" max="30"></div>
          <div class="fld"><label>Mover: |day change| &ge; %</label><input type="number" step="0.1" id="dvMover"></div>
          <div class="fld"><label>Mover: |5-min move| &ge; %</label><input type="number" step="0.05" id="dvMom"></div>
        </div>
        <button class="btn block" style="margin-top:14px" id="dvSave">Save Settings</button>
        <div style="display:flex;gap:8px;margin-top:8px">
          <button class="btn primary" style="flex:1" id="dvToggle">Start Streaming</button>
          <button class="btn" id="dvTest">Push Now</button>
        </div>
        <div class="small muted" style="margin-top:14px;line-height:1.7" id="dvStatus"></div>
      </div>
    </div>
    <div class="card">
      <div class="card-h"><h3>Generated Preview</h3><span class="tag live" id="pvLabelLg">-</span></div>
      <div class="card-b"><img class="preview" id="pvImgLg" alt="device preview" style="max-width:640px;margin:0 auto"></div>
    </div>
    <div class="card">
      <div class="card-h"><h3>Rotation Plan</h3><span class="small muted">4 tickers per page</span></div>
      <div class="card-b" id="dvPlan"></div>
      <div class="card-b small muted" style="border-top:1px solid var(--line);line-height:1.6">
        Tickers moving beyond your thresholds form the <b>TOP MOVERS</b> page. It is shown on every other slot, and the remaining tickers rotate through the slots in between. With no movers, all pages cycle in order of movement.
      </div>
    </div>
  </div>
</section>
</main>
<div class="toast" id="toast"></div>

<script>
const G='#2ed3a0', R='#f0506e', ACC='#6d5dfc';
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const S={state:null,selected:null,detail:null,range:'1D',ctype:'candle',view:'dashboard',bottom:'alerts',scr:null,scrBuilt:false,scrSort:{k:null,dir:-1},alertSel:null,alertPrice:0,devInit:false};

async function api(url,opts){const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),15000);let r;
 try{r=await fetch(url,{cache:'no-store',...opts,signal:opts?.signal||controller.signal});}finally{clearTimeout(timer);}const j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(j.error||('HTTP '+r.status));return j;}
const post=(url,b)=>api(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b||{})});
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function fp(v){if(v==null||isNaN(v))return '--';const a=Math.abs(v);const d=a>=1?2:a>=0.01?4:6;return Number(v).toLocaleString('en-US',{minimumFractionDigits:d,maximumFractionDigits:d});}
function fpct(v){if(v==null||isNaN(v))return '--';return (v>=0?'+':'')+Number(v).toFixed(2)+'%';}
function fbig(v){if(v==null||isNaN(v))return '--';const a=Math.abs(v);if(a>=1e12)return (v/1e12).toFixed(2)+'T';if(a>=1e9)return (v/1e9).toFixed(2)+'B';if(a>=1e6)return (v/1e6).toFixed(2)+'M';if(a>=1e3)return (v/1e3).toFixed(1)+'K';return Number(v).toFixed(0);}
function fnum(v,d){return v==null||isNaN(v)?'--':Number(v).toFixed(d==null?2:d);}
function ago(ts){if(!ts)return '--';const s=Math.max(0,Date.now()/1000-ts);if(s<60)return Math.floor(s)+'s ago';if(s<3600)return Math.floor(s/60)+'m ago';if(s<86400)return Math.floor(s/3600)+'h ago';return Math.floor(s/86400)+'d ago';}
function until(ts){if(!ts)return '--';const s=ts-Date.now()/1000;if(s<=0)return 'now';if(s<60)return 'in '+Math.ceil(s)+'s';return 'in '+Math.ceil(s/60)+'m';}
function hhmm(ts){return new Date(ts*1000).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit',second:'2-digit'});}
function toast(m,err){const t=$('#toast');t.textContent=m;t.className='toast show'+(err?' err':'');clearTimeout(t._h);t._h=setTimeout(()=>{t.className='toast'+(err?' err':'');},2600);}
function chip(p){return p==null||isNaN(p)?'<span class="chip na">--</span>':`<span class="chip ${p>=0?'up':'dn'}">${fpct(p)}</span>`;}

function drawSpark(cv,data,prev,up){
  const dpr=window.devicePixelRatio||1,w=cv.clientWidth,h=cv.clientHeight;if(!w||!h)return;
  cv.width=w*dpr;cv.height=h*dpr;const c=cv.getContext('2d');c.scale(dpr,dpr);c.clearRect(0,0,w,h);
  if(!data||data.length<2)return;
  let mn=Math.min(...data),mx=Math.max(...data);if(prev!=null){mn=Math.min(mn,prev);mx=Math.max(mx,prev);}const r=(mx-mn)||1;
  const X=i=>i/(data.length-1)*w,Y=v=>h-2-((v-mn)/r)*(h-4);
  const g=c.createLinearGradient(0,0,0,h);g.addColorStop(0,up?'rgba(46,211,160,.35)':'rgba(240,80,110,.35)');g.addColorStop(1,'rgba(0,0,0,0)');
  c.beginPath();data.forEach((v,i)=>i?c.lineTo(X(i),Y(v)):c.moveTo(X(i),Y(v)));c.lineTo(w,h);c.lineTo(0,h);c.closePath();c.fillStyle=g;c.fill();
  c.beginPath();data.forEach((v,i)=>i?c.lineTo(X(i),Y(v)):c.moveTo(X(i),Y(v)));c.strokeStyle=up?G:R;c.lineWidth=1.5;c.stroke();
  if(prev!=null){c.setLineDash([2,3]);c.strokeStyle='rgba(125,136,173,.55)';c.lineWidth=1;c.beginPath();c.moveTo(0,Y(prev));c.lineTo(w,Y(prev));c.stroke();c.setLineDash([]);}
}

function attachSearch(input,dd,onPick){
  let timer;
  input.addEventListener('input',e=>{
    clearTimeout(timer);const q=e.target.value.trim();
    if(q.length<1){dd.style.display='none';return;}
    timer=setTimeout(async()=>{
      try{
        const data=await api('/api/search?q='+encodeURIComponent(q));
        if(input.value.trim()!==q)return;
        dd.innerHTML='';
        data.forEach(it=>{
          const d=document.createElement('div');d.className='it';
          d.innerHTML=`<div><b>${esc(it.symbol)}</b><div class="small muted">${esc(it.name)}</div></div><span>${esc(it.exchange)}<br>${esc(it.type)}</span>`;
          d.onclick=()=>{dd.style.display='none';onPick(it);};dd.appendChild(d);
        });
        dd.style.display=data.length?'block':'none';
      }catch(err){dd.style.display='none';}
    },280);
  });
  input.addEventListener('keydown',e=>{if(e.key==='Enter'){const f=dd.querySelector('.it');if(f)f.click();}});
  document.addEventListener('click',e=>{if(!dd.contains(e.target)&&e.target!==input)dd.style.display='none';});
}

$$('.tabs button').forEach(b=>b.onclick=()=>showView(b.dataset.view));
function showView(v){
  S.view=v;$$('.tabs button').forEach(b=>b.classList.toggle('active',b.dataset.view===v));
  $$('.view').forEach(s=>s.classList.toggle('active',s.id==='view-'+v));
  if(v==='screener')loadScreener();
  render();
}
function setMode(m){document.body.classList.toggle('simple',m==='simple');$$('#modeSeg button').forEach(b=>b.classList.toggle('on',b.dataset.mode===m));localStorage.setItem('sky_mode',m);}
$$('#modeSeg button').forEach(b=>b.onclick=()=>setMode(b.dataset.mode));

let tickBusy=false;
async function tick(){
  if(tickBusy)return;tickBusy=true;
  try{
    const st=await api('/api/state');S.state=st;
    if(!S.selected){S.selected=st.selected||(st.watchlist[0]||{}).symbol||null;if(S.selected){loadDetail();loadChart();}}
    render();
  }catch(e){const p=$('#devPill');p.className='pill err';p.querySelector('span').textContent='Server offline';}
  finally{tickBusy=false;}
}
function render(){
  const st=S.state;if(!st)return;
  renderNav(st);renderWatchlist(st);renderStrip(st);renderMovers(st);renderBreadth(st);renderPreview(st);renderBottom(st);renderNews(st);updateLiveChart(st);
  if(S.view==='alerts')renderAlertBook(st);
  if(S.view==='device')renderDevice(st);
}
function renderNav(st){
  const d=st.device,p=$('#devPill');
  p.className='pill '+(d.status==='confirmed'?'on':(['unreachable','stale'].includes(d.status)?'err':''));
  p.querySelector('span').textContent=deviceLabel(d);
  const b=$('#devBtn');b.textContent=d.running?'Stop Device':'Start Device';b.className='btn '+(d.running?'danger':'primary');
}
async function toggleDevice(){
  const run=!S.state.device.running;const ip=$('#dvIp').value.trim();
  try{await post('/api/device',Object.assign({running:run},ip?{ip:ip}:{}));toast(run?'Streaming to device':'Device streaming stopped');tick();}catch(e){toast(e.message,true);}
}
$('#devBtn').onclick=toggleDevice;

function renderWatchlist(st){
  const wl=st.watchlist,live=new Set(st.device.status==='confirmed'?(st.device.symbols||[]):[]);$('#wlCount').textContent=wl.length;
  $('#wlList').innerHTML=wl.length?wl.map((q,i)=>`
    <div class="wl-row ${q.symbol===S.selected?'sel':''}" data-sym="${esc(q.symbol)}">
      <div style="min-width:0"><div class="sym">${esc(q.symbol)}${q.mover?'<span class="tag mover">MOVER</span>':''}${live.has(q.symbol)?'<span class="tag live">ON SCREEN</span>':''}</div><div class="nm">${esc(q.name)} · <span class="small">${esc(q.freshness||'waiting')}</span></div></div>
      <canvas data-i="${i}"></canvas>
      <div class="wl-px"><div class="px mono">${fp(q.price)}</div>${chip(q.ok?q.pct:null)}</div>
      <div class="wl-act"><button class="icon-btn" data-act="up" title="Move up">&#9650;</button><button class="icon-btn" data-act="down" title="Move down">&#9660;</button><button class="icon-btn" data-act="rn" title="Rename">&#9998;</button><button class="icon-btn" data-act="rm" title="Remove" style="color:var(--dn)">&#10005;</button></div>
    </div>`).join(''):'<div class="empty">Your watchlist is empty.<br>Click <b>+ Add</b> to start monitoring.</div>';
  $$('#wlList canvas').forEach(cv=>{const q=wl[+cv.dataset.i];drawSpark(cv,q.spark,q.prev_close,(q.change||0)>=0);});
}
$('#wlList').addEventListener('click',async e=>{
  const row=e.target.closest('.wl-row');if(!row)return;const sym=row.dataset.sym;const btn=e.target.closest('[data-act]');
  if(!btn){selectSymbol(sym);return;}
  e.stopPropagation();const act=btn.dataset.act;
  try{
    if(act==='rm'){await post('/api/watchlist/remove',{symbol:sym});toast(sym+' removed');}
    else if(act==='up'||act==='down'){await post('/api/watchlist/move',{symbol:sym,dir:act==='up'?-1:1});}
    else if(act==='rn'){const n=prompt('Display name for '+sym+' (first 14 chars shown on device):');if(n)await post('/api/watchlist/rename',{symbol:sym,name:n});}
    tick();
  }catch(err){toast(err.message,true);}
});
$('#wlAddBtn').onclick=()=>{const a=$('#wlAdd');a.classList.toggle('open');if(a.classList.contains('open'))$('#wlSearch').focus();};
attachSearch($('#wlSearch'),$('#wlDD'),async it=>{
  try{await post('/api/watchlist/add',{symbol:it.symbol,name:it.name});$('#wlSearch').value='';toast(it.symbol+' added to watchlist');await tick();selectSymbol(it.symbol);}
  catch(e){toast(e.message,true);}
});
async function addToWatchlist(sym,name){try{await post('/api/watchlist/add',{symbol:sym,name:name||sym});toast(sym+' added to watchlist');tick();}catch(e){toast(e.message,true);}}
function selectSymbol(sym){S.selected=sym;S.detail=null;post('/api/select',{symbol:sym}).catch(()=>{});render();loadDetail();loadChart();}

async function loadDetail(){const sym=S.selected;if(!sym)return;try{const d=await api('/api/quote?symbol='+encodeURIComponent(sym));if(sym===S.selected){S.detail=d;renderStrip(S.state);}}catch(e){}}
function renderStrip(st){
  const el=$('#strip'),sym=S.selected;
  if(!sym){el.innerHTML='<div class="muted">Add a ticker to begin</div>';return;}
  const wq=((st&&st.watchlist)||[]).find(q=>q.symbol===sym);const d=S.detail&&S.detail.symbol===sym?S.detail:null;
  const sq=st&&st.selected_quote&&st.selected_quote.symbol===sym?st.selected_quote:null;const q=wq||(sq&&sq.ok?sq:d)||{};const det=(d&&d.detail)||{};const up=(q.change||0)>=0;
  const lo=det.year_low,hi=det.year_high,px=q.price;
  const pos=(hi&&lo&&px&&hi>lo)?Math.min(100,Math.max(0,(px-lo)/(hi-lo)*100)):null;
  const letter=(sym.replace(/[^A-Za-z0-9]/g,'')[0]||'?').toUpperCase();
  el.innerHTML=`
   <div class="s-id"><div class="avatar">${esc(letter)}</div><div><div class="s-sym">${esc(sym)}</div><div class="small muted">${esc(q.name||'')}${det.exchange?' · '+esc(det.exchange):''}${det.currency?' · '+esc(det.currency):''}</div></div></div>
   <div><div class="big mono">${fp(px)}</div><div class="mono ${up?'up':'dn'}" style="margin-top:3px">${fpct(q.pct)} (${q.change!=null?(q.change>=0?'+':'')+fp(q.change):'--'})</div></div>
   <div class="kv"><div class="k">Day High</div><div class="v mono">${fp(q.high!=null?q.high:det.day_high)}</div></div>
   <div class="kv"><div class="k">Day Low</div><div class="v mono">${fp(q.low!=null?q.low:det.day_low)}</div></div>
   <div class="kv"><div class="k">Volume</div><div class="v mono">${fbig(q.volume!=null?q.volume:det.last_volume)}</div></div>
   <div class="kv adv"><div class="k">52W Range</div><div class="range"><span class="mono small">${fp(lo)}</span><div class="rbar">${pos!=null?`<i style="left:${pos}%"></i>`:''}</div><span class="mono small">${fp(hi)}</span></div></div>
   <div class="kv adv"><div class="k">Market Cap</div><div class="v mono">${fbig(det.market_cap)}</div></div>
   <div class="kv adv"><div class="k">5-min Momentum</div><div class="v mono ${(q.momentum||0)>=0?'up':'dn'}">${fpct(q.momentum)}</div></div>
   <div class="kv"><div class="k">Market timestamp</div><div class="v">${q.market_time?ago(q.market_time):'--'}</div><span class="small muted">${esc(q.freshness||q.source||'waiting')}</span></div>
   <div class="s-act"><button class="btn sm" id="stripAlert">&#128276; Set Alert</button>${wq?'':'<button class="btn sm primary" id="stripAdd">+ Watchlist</button>'}</div>`;
  $('#stripAlert').onclick=()=>{showView('alerts');pickAlert(sym,q.name||sym);};
  const sa=$('#stripAdd');if(sa)sa.onclick=()=>addToWatchlist(sym,q.name||sym);
}

let chart=null,candleS,areaS,volS,prevLine=null,bars=[];
let chartRequest=0,chartLoading=false,chartKey='',chartAbort=null,lastLiveStamp=0,lastLivePrice=null;
function deviceLabel(d){return ({confirmed:'Push confirmed · '+d.ip,connecting:'Connecting · '+d.ip,unreachable:'Device unreachable',stale:'Device confirmation stale',stopped:'Device stopped'})[d.status]||'Waiting for device';}
function renderNews(st){
 const ns=st.news_status||{},feed=st.feed||{};
 $('#feedStatus').textContent=(feed.mode==='streaming'?'Price stream enabled':'Price feed: '+(feed.mode||'starting'))+' · UI checks every second · Exchange/provider delays may apply'+(feed.error?' · '+feed.error:'');
 $('#newsStatus').textContent='Checks every '+(ns.refresh_seconds||30)+'s · '+(ns.last_check?'Last check '+ago(ns.last_check):'Waiting for provider')+(ns.error?' · '+ns.error:'');
 const rows=st.news||[];
 $('#watchNews').innerHTML=rows.length?rows.map(n=>`<div style="padding:8px 0;border-bottom:1px solid var(--line)"><div class="small muted">${(n.symbols||[]).map(esc).join(', ')} · ${esc(n.publisher)} · ${n.ts?esc(new Date(n.ts*1000).toLocaleString())+' ('+ago(n.ts)+')':'Publication time unavailable'}</div><div style="margin-top:4px">${n.link?`<a href="${esc(n.link)}" target="_blank" rel="noopener noreferrer" style="color:var(--text);text-decoration:none">${esc(n.title)}</a>`:esc(n.title)}</div></div>`).join(''):'<div class="muted">No headlines available for this watchlist yet.</div>';
}
function updateLiveChart(st){
 if(!chart||chartKey!==S.selected+'|'+S.range||!bars.length||!['1D','5D','1M'].includes(S.range))return;
 const q=(st.watchlist||[]).find(x=>x.symbol===S.selected)||(st.selected_quote?.symbol===S.selected?st.selected_quote:null);
 if(!q||q.source!=='stream'||!q.price||!q.market_time||q.market_time<lastLiveStamp||(q.market_time===lastLiveStamp&&q.price===lastLivePrice))return;
 const width=({'1D':60,'5D':900,'1M':3600})[S.range],last=bars[bars.length-1];
 if(q.market_time<last.time)return;
 let bucket=last.time+Math.floor((q.market_time-last.time)/width)*width;
 // Let provider history establish a new session and its exchange bar boundaries.
 if(bucket-last.time>width){loadChart(true);return;}
 const b=bucket===last.time?{...last,close:q.price,high:Math.max(last.high,q.price),low:Math.min(last.low,q.price)}:{time:bucket,open:q.price,high:q.price,low:q.price,close:q.price,volume:0};
 if(bucket===last.time)bars[bars.length-1]=b;else bars.push(b);
 candleS.update({time:b.time,open:b.open,high:b.high,low:b.low,close:b.close});areaS.update({time:b.time,value:b.close});
 volS.update({time:b.time,value:b.volume,color:b.close>=b.open?'rgba(46,211,160,.4)':'rgba(240,80,110,.4)'});
 lastLiveStamp=q.market_time;lastLivePrice=q.price;setLegend(b);
}
function initChart(){
  if(!window.LightweightCharts){$('#chartMsg').style.display='grid';$('#chartMsg').textContent='Chart library unavailable (needs internet access to unpkg.com)';return;}
  chart=LightweightCharts.createChart($('#chart'),{autoSize:true,layout:{background:{type:'solid',color:'transparent'},textColor:'#7d88ad',fontFamily:'Inter'},
    grid:{vertLines:{color:'rgba(29,39,73,.55)'},horzLines:{color:'rgba(29,39,73,.55)'}},
    rightPriceScale:{borderColor:'#1d2749'},timeScale:{borderColor:'#1d2749',timeVisible:true,secondsVisible:false},
    crosshair:{mode:0,vertLine:{color:'#56608a',labelBackgroundColor:ACC},horzLine:{color:'#56608a',labelBackgroundColor:ACC}}});
  candleS=chart.addCandlestickSeries({upColor:G,downColor:R,borderVisible:false,wickUpColor:G,wickDownColor:R});
  areaS=chart.addAreaSeries({lineColor:'#8b7dff',topColor:'rgba(109,93,252,.4)',bottomColor:'rgba(109,93,252,0)',lineWidth:2,visible:false});
  volS=chart.addHistogramSeries({priceFormat:{type:'volume'},priceScaleId:'vol'});
  chart.priceScale('vol').applyOptions({scaleMargins:{top:0.82,bottom:0}});
  chart.priceScale('right').applyOptions({scaleMargins:{top:0.08,bottom:0.22}});
  chart.subscribeCrosshairMove(p=>{
    if(!p||!p.time){setLegend(bars[bars.length-1]);return;}
    setLegend(bars.find(x=>x.time===p.time));
  });
}
function setLegend(b){
  if(!b){$('#legend').innerHTML='';return;}
  const ch=b.close-b.open,pc=b.open?ch/b.open*100:0;
  $('#legend').innerHTML=`<span>O <b>${fp(b.open)}</b></span><span>H <b>${fp(b.high)}</b></span><span>L <b>${fp(b.low)}</b></span><span>C <b>${fp(b.close)}</b></span><span class="${ch>=0?'up':'dn'}">${ch>=0?'+':''}${fp(ch)} (${fpct(pc)})</span><span>Vol <b>${fbig(b.volume)}</b></span>`;
}
function applyChartType(){if(!chart)return;candleS.applyOptions({visible:S.ctype==='candle'});areaS.applyOptions({visible:S.ctype==='line'});}
async function loadChart(keep){
  if(!chart||!S.selected)return;const sym=S.selected,rng=S.range;
  if(keep&&chartLoading)return;
  if(chartAbort)chartAbort.abort();chartAbort=new AbortController();
  const controller=chartAbort,version=++chartRequest;chartLoading=true;
  const timeout=setTimeout(()=>controller.abort(),15000);
  $('#chartTitle').innerHTML=`${esc(sym)} <span class="muted small" style="font-weight:400">${rng} · UTC</span>`;
  if(!keep){$('#chartMsg').style.display='grid';$('#chartMsg').textContent='Loading '+sym+'...';}
  try{
    const d=await api(`/api/history?symbol=${encodeURIComponent(sym)}&range=${rng}`,{signal:controller.signal});
    if(version!==chartRequest||sym!==S.selected||rng!==S.range)return;
    if(d.error&&keep&&bars.length)throw new Error(d.error);
    bars=d.bars||[];chartKey=sym+'|'+rng;lastLiveStamp=0;lastLivePrice=null;
    candleS.setData(bars.map(b=>({time:b.time,open:b.open,high:b.high,low:b.low,close:b.close})));
    areaS.setData(bars.map(b=>({time:b.time,value:b.close})));
    volS.setData(bars.map(b=>({time:b.time,value:b.volume,color:b.close>=b.open?'rgba(46,211,160,.4)':'rgba(240,80,110,.4)'})));
    if(prevLine){candleS.removePriceLine(prevLine);prevLine=null;}
    if(rng==='1D'&&d.prev_close)prevLine=candleS.createPriceLine({price:d.prev_close,color:'#7d88ad',lineStyle:2,lineWidth:1,axisLabelVisible:true,title:'Prev close'});
    applyChartType();if(!keep)chart.timeScale().fitContent();setLegend(bars[bars.length-1]);
    $('#chartMsg').style.display=bars.length?'none':'grid';$('#chartMsg').textContent=d.error||'No data for this range';
    if(S.state)updateLiveChart(S.state);
  }catch(e){if(version===chartRequest){$('#chartMsg').style.display='grid';$('#chartMsg').textContent='Chart update failed; '+(keep?'last data retained: ':'')+e.message;}}
  finally{clearTimeout(timeout);if(version===chartRequest)chartLoading=false;}
}
$$('#tfBtns button').forEach(b=>b.onclick=()=>{S.range=b.dataset.r;$$('#tfBtns button').forEach(x=>x.classList.toggle('on',x===b));loadChart();});
$$('#ctSeg button').forEach(b=>b.onclick=()=>{S.ctype=b.dataset.t;$$('#ctSeg button').forEach(x=>x.classList.toggle('on',x===b));applyChartType();});

function renderMovers(st){
  const rows=st.watchlist.filter(q=>q.ok&&q.pct!=null).sort((a,b)=>Math.abs(b.pct)-Math.abs(a.pct)).slice(0,7);
  if(!rows.length){$('#movers').innerHTML='<div class="empty">Waiting for data...</div>';return;}
  const mx=Math.max(...rows.map(r=>Math.abs(r.pct)),0.01);
  $('#movers').innerHTML=rows.map(r=>`<div class="mv-row" data-sym="${esc(r.symbol)}"><div style="font-weight:600;overflow:hidden;text-overflow:ellipsis">${esc(r.symbol)}</div><div class="mv-bar"><i style="width:${Math.abs(r.pct)/mx*100}%;background:${r.pct>=0?G:R}"></i></div><div class="mono small ${r.pct>=0?'up':'dn'}" style="text-align:right">${fpct(r.pct)}</div></div>`).join('');
}
$('#movers').addEventListener('click',e=>{const r=e.target.closest('.mv-row');if(r)selectSymbol(r.dataset.sym);});
function renderBreadth(st){
  const q=st.watchlist.filter(x=>x.ok&&x.pct!=null);const a=q.filter(x=>x.pct>0.05).length,d=q.filter(x=>x.pct<-0.05).length,f=q.length-a-d;
  const avg=q.length?q.reduce((s,x)=>s+x.pct,0)/q.length:0;const tot=q.length||1;const movers=st.watchlist.filter(x=>x.mover).length;
  $('#breadth').innerHTML=`<div class="stat3"><div><div class="v up">${a}</div><div class="small muted">Advancing</div></div><div><div class="v">${f}</div><div class="small muted">Flat</div></div><div><div class="v dn">${d}</div><div class="small muted">Declining</div></div></div>
   <div class="breadth"><div class="a" style="width:${a/tot*100}%"></div><div style="width:${f/tot*100}%;background:#39426b"></div><div class="d" style="width:${d/tot*100}%"></div></div>
   <div style="display:flex;justify-content:space-between" class="small"><span class="muted">Avg change <b class="mono ${avg>=0?'up':'dn'}">${fpct(avg)}</b></span><span class="muted">Movers <b style="color:var(--warn)">${movers}</b></span></div>`;
}
function renderPreview(st){
  const d=st.device,src='/api/preview.jpg?v='+d.preview_version;
  if($('#pvImg').getAttribute('src')!==src)$('#pvImg').src=src;$('#pvLabel').textContent=d.preview_label||'-';
  const plan=st.plan||[];const idx=plan.findIndex(p=>p.label===d.label);
  const nxt=plan.length>1?plan[(idx+1)%plan.length]:null;
  $('#pvNext').textContent='Generated preview · '+deviceLabel(d);
  if(S.view==='device'){if($('#pvImgLg').getAttribute('src')!==src)$('#pvImgLg').src=src;$('#pvLabelLg').textContent=d.preview_label||'-';}
}

$$('#bottomTabs button').forEach(b=>b.onclick=()=>{S.bottom=b.dataset.b;$$('#bottomTabs button').forEach(x=>x.classList.toggle('on',x===b));renderBottom(S.state);});
function alertTable(alerts,full){
  if(!alerts.length)return '<div class="empty">No alerts yet. Create one from the Alerts tab or the "Set Alert" button.</div>';
  return `<table class="tbl"><thead><tr><th>Ticker</th><th>Condition</th><th class="r">Target</th><th class="r">Current</th><th>Distance</th><th>Status</th>${full?'<th>Note</th><th>Created</th>':''}<th></th></tr></thead><tbody>`+
  alerts.map(a=>{
    const cur=a.triggered?a.triggered_price:a.current;const dist=cur?(a.target_price-cur)/cur*100:null;
    const span=a.target_price-a.base_price;const prog=cur&&span?Math.min(100,Math.max(0,(cur-a.base_price)/span*100)):0;
    return `<tr><td><b>${esc(a.symbol)}</b><div class="small muted">${esc(a.name)}</div></td><td class="mono">${a.condition==='>='?'&ge; Breakout':'&le; Pullback'}</td>
     <td class="r mono">${fp(a.target_price)}</td><td class="r mono">${fp(cur)}</td>
     <td><div style="display:flex;align-items:center;gap:8px"><div class="prog"><i style="width:${a.triggered?100:prog}%"></i></div><span class="mono small ${dist==null?'':(dist>=0?'up':'dn')}">${a.triggered?'hit':fpct(dist)}</span></div></td>
     <td>${a.triggered?`<span class="badge hit">TRIGGERED</span><div class="small muted">${ago(a.triggered_at)}</div>`:'<span class="badge armed">ARMED</span>'}</td>
     ${full?`<td class="muted">${esc(a.note||'')}</td><td class="muted small">${ago(a.created)}</td>`:''}
     <td class="r">${a.triggered?`<button class="btn sm" data-rearm="${esc(a.id)}">Re-arm</button> `:''}<button class="btn sm danger" data-del="${esc(a.id)}">Delete</button></td></tr>`;}).join('')+'</tbody></table>';
}
async function alertAction(e){
  const del=e.target.closest('[data-del]'),re=e.target.closest('[data-rearm]');
  try{
    if(del){await post('/api/alerts/delete',{id:del.dataset.del});toast('Alert deleted');tick();}
    if(re){await post('/api/alerts/rearm',{id:re.dataset.rearm});toast('Alert re-armed');tick();}
  }catch(err){toast(err.message,true);}
}
function renderBottom(st){
  const b=$('#bottomBody');const armed=st.alerts.filter(a=>!a.triggered).length;const tabs=$$('#bottomTabs button');
  tabs[0].textContent=`Price Alerts (${st.alerts.length})`;tabs[1].textContent=`Screener Hits (${st.screener_hits.length})`;
  if(S.bottom==='alerts'){$('#bottomInfo').textContent=armed+' armed';b.innerHTML=alertTable(st.alerts,false);}
  else if(S.bottom==='hits'){
    const sc=st.screener;$('#bottomInfo').textContent=sc.enabled?('Engine on · last scan '+ago(sc.last_scan)):'Engine off';
    b.innerHTML=st.screener_hits.length?`<table class="tbl"><thead><tr><th>Ticker</th><th class="r">Price</th><th class="r">Chg %</th><th class="r">Rel Vol</th><th class="r">RSI</th><th></th></tr></thead><tbody>${st.screener_hits.map(h=>`<tr><td><b>${esc(h.symbol)}</b><div class="small muted">${esc(h.name)}</div></td><td class="r mono">${fp(h.price)}</td><td class="r">${chip(h.pct)}</td><td class="r mono">${h.rel_volume?fnum(h.rel_volume)+'x':'--'}</td><td class="r mono">${fnum(h.rsi,1)}</td><td class="r"><button class="btn sm" data-chart="${esc(h.symbol)}">Chart</button> <button class="btn sm primary" data-add="${esc(h.symbol)}" data-name="${esc(h.name)}">+</button></td></tr>`).join('')}</tbody></table>`:'<div class="empty">No screener matches yet. Configure it in the Screener tab.</div>';
  } else {
    $('#bottomInfo').textContent=st.events.length+' events';
    b.innerHTML=st.events.length?`<table class="tbl"><thead><tr><th>Time</th><th>Type</th><th>Message</th></tr></thead><tbody>${st.events.map(e=>`<tr><td class="mono muted">${hhmm(e.ts)}</td><td><span class="badge ${esc(e.kind)}">${esc(e.kind.toUpperCase())}</span></td><td>${esc(e.msg)}</td></tr>`).join('')}</tbody></table>`:'<div class="empty">No events yet</div>';
  }
}
$('#bottomBody').addEventListener('click',e=>{
  alertAction(e);
  const c=e.target.closest('[data-chart]');if(c){selectSymbol(c.dataset.chart);window.scrollTo({top:0,behavior:'smooth'});}
  const a=e.target.closest('[data-add]');if(a)addToWatchlist(a.dataset.add,a.dataset.name);
});

const NUMF=(k,l)=>({k:k,l:l,t:'num'});
const SCHEMA=[
 {g:'Universe & Market',open:true,f:[{k:'universe',l:'Market / universe',t:'universe',w:1},{k:'custom_symbols',l:'Custom symbols (used when universe = Custom)',t:'area',w:1}]},
 {g:'Price & Performance',open:true,f:[{k:'direction',l:'Direction',t:'select',o:[['any','Up or down'],['up','Gainers only'],['down','Losers only']]},NUMF('change_min','Min |day change| %'),NUMF('gap_min','Min |gap| %'),NUMF('near_high_pct','Within % of 52W high'),NUMF('price_min','Min price'),NUMF('price_max','Max price')]},
 {g:'Volume & Liquidity',open:true,f:[NUMF('volume_min','Min volume (today)'),NUMF('rel_volume_min','Min rel. volume (x 20D avg)')]},
 {g:'Fundamentals',open:false,f:[NUMF('mcap_min_b','Min market cap (local B)'),NUMF('mcap_max_b','Max market cap (local B)'),NUMF('pe_min','Min P/E'),NUMF('pe_max','Max P/E'),NUMF('eps_min','Min EPS (TTM)'),NUMF('eps_growth_min','Min quarterly earnings growth %'),NUMF('div_yield_min','Min dividend yield %'),{k:'rating',l:'Analyst rating',t:'select',o:[['any','Any'],['buy','Buy or better'],['strong_buy','Strong buy']]},{k:'sector',l:'Sector contains (e.g. Technology, Energy)',t:'text',w:1}]},
 {g:'Technicals',open:false,f:[NUMF('rsi_min','Min RSI (14)'),NUMF('rsi_max','Max RSI (14)'),{k:'above_sma50',l:'Price above 50-day SMA',t:'check',w:1},{k:'above_sma200',l:'Price above 200-day SMA',t:'check',w:1}]},
 {g:'News & Events',open:false,f:[NUMF('news_hours','In the news within N hours'),{k:'news_keyword',l:'Headline keyword',t:'text'},NUMF('earnings_days','Earnings within N days'),{k:'show_headlines',l:'Show latest headline for matches',t:'check',w:1}]},
 {g:'Engine',open:false,f:[NUMF('scan_interval','Rescan every (sec, min 30)'),NUMF('max_results','Max results'),{k:'sort_by',l:'Rank by',t:'select',w:1,o:[['abs_change','Biggest mover (|%|)'],['change','Top gainers'],['rel_volume','Relative volume'],['volume','Volume'],['gap','Gap size'],['rsi','RSI'],['mcap','Market cap'],['upside','Analyst upside']]},{k:'push_to_display',l:'Push new matches to SkyLoong display',t:'check',w:1}]}
];
const FILTER_KEYS=['direction','change_min','gap_min','near_high_pct','price_min','price_max','volume_min','rel_volume_min','mcap_min_b','mcap_max_b','pe_min','pe_max','eps_min','eps_growth_min','div_yield_min','rating','sector','rsi_min','rsi_max','above_sma50','above_sma200','news_hours','news_keyword','earnings_days'];
const PRESETS={
 momentum:{direction:'up',change_min:3,rel_volume_min:1.5,rsi_min:55,above_sma50:true},
 breakout:{direction:'up',change_min:1,near_high_pct:3,rel_volume_min:1.3,above_sma50:true,above_sma200:true},
 oversold:{rsi_max:30,above_sma200:true},
 value:{pe_max:15,eps_min:0.01,mcap_min_b:10,div_yield_min:1},
 growth:{eps_growth_min:20,mcap_min_b:2,above_sma50:true,rating:'buy'},
 news:{news_hours:12,change_min:1.5},
 earnings:{earnings_days:7},
 clear:{}
};
function allFields(){return SCHEMA.flatMap(g=>g.f);}
function fieldHTML(f){
  const id='f_'+f.k,w=f.w?' wide':'';
  if(f.t==='check')return `<label class="check${w}"><input type="checkbox" id="${id}"> ${esc(f.l)}</label>`;
  if(f.t==='select')return `<div class="fld${w}"><label for="${id}">${esc(f.l)}</label><select id="${id}">${f.o.map(o=>`<option value="${o[0]}">${esc(o[1])}</option>`).join('')}</select></div>`;
  if(f.t==='universe'){
    const groups={};(S.scr.universes||[]).forEach(u=>{(groups[u.market]=groups[u.market]||[]).push(u);});
    return `<div class="fld${w}"><label for="${id}">${esc(f.l)}</label><select id="${id}">${Object.keys(groups).map(g=>`<optgroup label="${esc(g)}">${groups[g].map(u=>`<option value="${esc(u.key)}">${esc(u.label)}</option>`).join('')}</optgroup>`).join('')}</select></div>`;
  }
  if(f.t==='area')return `<div class="fld${w}"><label for="${id}">${esc(f.l)}</label><textarea id="${id}" placeholder="AAPL, MSFT, RELIANCE.NS, 2222.SR"></textarea></div>`;
  if(f.t==='text')return `<div class="fld${w}"><label for="${id}">${esc(f.l)}</label><input id="${id}" placeholder="Any"></div>`;
  return `<div class="fld${w}"><label for="${id}">${esc(f.l)}</label><input type="number" step="any" id="${id}" placeholder="Any"></div>`;
}
function buildScrForm(){
  $('#scrForm').innerHTML=SCHEMA.map(g=>`<details class="grp" ${g.open?'open':''}><summary>${esc(g.g)}</summary><div class="gb"><div class="fgrid">${g.f.map(fieldHTML).join('')}</div></div></details>`).join('');
  setScrForm(S.scr.settings);S.scrBuilt=true;
}
function setScrForm(s){
  allFields().forEach(f=>{const el=$('#f_'+f.k);if(!el)return;const v=s[f.k];
    if(f.t==='check')el.checked=!!v;else el.value=(v==null?'':v);});
}
function readScrForm(){
  const o={};allFields().forEach(f=>{const el=$('#f_'+f.k);if(!el)return;
    if(f.t==='check')o[f.k]=el.checked;else if(f.t==='num')o[f.k]=el.value===''?null:Number(el.value);else o[f.k]=el.value;});
  return o;
}
$$('#presets button').forEach(b=>b.onclick=()=>{
  if(!S.scrBuilt)return;
  const cur=readScrForm();
  FILTER_KEYS.forEach(k=>{const f=allFields().find(x=>x.k===k);cur[k]=f.t==='check'?false:(f.t==='select'?'any':(f.t==='num'?null:''));});
  Object.assign(cur,PRESETS[b.dataset.p]);setScrForm(cur);toast(b.textContent+' preset applied. Click Save & Scan.');
});
async function saveScr(){if(S.scrBuilt)await post('/api/screener/settings',readScrForm());}
$('#scrSaveBtn').onclick=async()=>{try{await saveScr();toast('Screener settings saved');}catch(e){toast(e.message,true);}};
$('#scrScanBtn').onclick=async()=>{try{await saveScr();await post('/api/screener/scan');toast('Scan started');setTimeout(loadScreener,600);}catch(e){toast(e.message,true);}};
$('#scrEnabled').onchange=async()=>{try{await saveScr();const r=await post('/api/screener/toggle');$('#scrEnabled').checked=r.enabled;toast('Auto-scan '+(r.enabled?'enabled':'disabled'));loadScreener();}catch(e){toast(e.message,true);}};
let screenerLoading=false;
async function loadScreener(){
  if(screenerLoading)return;screenerLoading=true;
  try{const d=await api('/api/screener');S.scr=d;if(!S.scrBuilt)buildScrForm();renderScrStatus(d);renderScrResults(d);}catch(e){$('#stLast').textContent='Status unavailable';}finally{screenerLoading=false;}
}
function renderScrStatus(d){
  const s=d.status;$('#scrEnabled').checked=!!s.enabled;
  $('#stUni').textContent=s.universe_label||'-';
  $('#stScan').textContent=s.total?`${s.progress}/${s.total}`:'-';
  $('#stMatch').textContent=s.last_scan?s.matched:'-';
  $('#stLast').textContent=s.error?s.error:(s.scanning?'Scanning '+(s.phase||'')+'...':(s.last_scan?ago(s.last_scan)+(s.duration?` (${s.duration.toFixed(0)}s)`:''):'Never'));
  $('#stNext').textContent=s.enabled?until(s.next_scan):'Engine off';
  const p=$('#scrProg');p.style.display=s.scanning?'block':'none';p.firstElementChild.style.width=(s.total?s.progress/s.total*100:0)+'%';
}
const SCOLS=[['symbol','Ticker'],[null,'30D'],['price','Price',1],['pct','Chg %',1],['gap','Gap %',1],['volume','Volume',1],['rel_volume','Rel Vol',1],['rsi','RSI',1],['pe','P/E',1],['eps','EPS',1],['mcap','Mkt Cap',1],['from_high','Off High',1],['upside','Upside',1],['sector','Sector'],[null,'Latest News'],[null,'']];
function renderScrResults(d){
  let rows=[...d.results];$('#scrCount').textContent=rows.length;
  const k=S.scrSort.k;if(k)rows.sort((a,b)=>{const x=a[k],y=b[k];if(x==null)return 1;if(y==null)return -1;return (typeof x==='string'?x.localeCompare(y):x-y)*S.scrSort.dir;});
  drawDist($('#scrDist'),[...d.results].sort((a,b)=>b.pct-a.pct));
  if(!rows.length){$('#scrTable').innerHTML=`<div class="empty">${esc(d.status.error||(d.status.scanning?'Scanning universe...':'No matches. Loosen filters or pick another universe, then Save & Scan.'))}</div>`;return;}
  const rsiCls=v=>v==null?'':(v>=70?'dn':(v<=30?'up':''));
  $('#scrTable').innerHTML=`<table class="tbl"><thead><tr>${SCOLS.map(c=>`<th class="${c[0]?'sort':''} ${c[2]?'r':''}" ${c[0]?`data-k="${c[0]}"`:''}>${c[1]}${S.scrSort.k===c[0]&&c[0]?(S.scrSort.dir>0?' &#9650;':' &#9660;'):''}</th>`).join('')}</tr></thead><tbody>`+
   rows.map((r,i)=>`<tr>
    <td><b>${esc(r.symbol)}</b><div class="small muted" style="max-width:160px;overflow:hidden;text-overflow:ellipsis">${esc(r.name)}${r.earnings?` · <span style="color:var(--warn)">ER ${esc(r.earnings)}</span>`:''}</div></td>
    <td><canvas data-si="${i}" style="width:70px;height:26px"></canvas></td>
    <td class="r mono">${fp(r.price)}</td><td class="r">${chip(r.pct)}</td>
    <td class="r mono ${r.gap>=0?'up':'dn'}">${fpct(r.gap)}</td><td class="r mono">${fbig(r.volume)}</td>
    <td class="r mono" style="${(r.rel_volume||0)>=1.5?'color:var(--warn)':''}">${r.rel_volume?fnum(r.rel_volume)+'x':'--'}</td>
    <td class="r mono ${rsiCls(r.rsi)}">${fnum(r.rsi,1)}</td><td class="r mono">${fnum(r.pe,1)}</td><td class="r mono">${fnum(r.eps)}</td>
    <td class="r mono">${fbig(r.mcap)}</td><td class="r mono">${r.from_high!=null?'-'+fnum(r.from_high,1)+'%':'--'}</td>
    <td class="r mono ${(r.upside||0)>=0?'up':'dn'}">${r.upside!=null?fpct(r.upside):'--'}</td>
    <td class="muted">${esc(r.sector||'--')}</td>
    <td class="news">${r.news?`<a href="${esc(r.news.link)}" target="_blank" rel="noopener" title="${esc(r.news.title)}">${esc(r.news.title)}</a><div class="small dim">${esc(r.news.publisher)}${r.news.ts?' · '+ago(r.news.ts):''}</div>`:'<span class="dim">--</span>'}</td>
    <td class="r"><button class="btn sm" data-chart="${esc(r.symbol)}">Chart</button> <button class="btn sm primary" data-add="${esc(r.symbol)}" data-name="${esc(r.name)}">+</button></td></tr>`).join('')+'</tbody></table>';
  $$('#scrTable canvas').forEach(cv=>{const r=rows[+cv.dataset.si];const s=r.spark||[];drawSpark(cv,s,null,s.length>1?s[s.length-1]>=s[0]:true);});
}
$('#scrTable').addEventListener('click',e=>{
  const th=e.target.closest('th[data-k]');
  if(th){const k=th.dataset.k;S.scrSort=S.scrSort.k===k?{k:k,dir:-S.scrSort.dir}:{k:k,dir:-1};renderScrResults(S.scr);return;}
  const c=e.target.closest('[data-chart]');if(c){selectSymbol(c.dataset.chart);showView('dashboard');return;}
  const a=e.target.closest('[data-add]');if(a)addToWatchlist(a.dataset.add,a.dataset.name);
});
function drawDist(cv,rows){
  const dpr=window.devicePixelRatio||1,w=cv.clientWidth,h=cv.clientHeight;if(!w)return;cv.width=w*dpr;cv.height=h*dpr;
  const c=cv.getContext('2d');c.scale(dpr,dpr);c.clearRect(0,0,w,h);c.font='11px Inter';
  const data=rows.slice(0,40);
  if(!data.length){c.fillStyle='#56608a';c.fillText('No matches yet',10,20);return;}
  const mx=Math.max(...data.map(r=>Math.abs(r.pct)),0.5),mid=h/2,bw=w/data.length;
  c.strokeStyle='#2a3663';c.beginPath();c.moveTo(0,mid);c.lineTo(w,mid);c.stroke();
  data.forEach((r,i)=>{const bh=Math.abs(r.pct)/mx*(mid-16);const x=i*bw+bw*0.15;
    c.fillStyle=r.pct>=0?G:R;c.globalAlpha=.85;c.fillRect(x,r.pct>=0?mid-bh:mid,Math.max(2,bw*0.7),bh);c.globalAlpha=1;
    if(bw>=34){c.fillStyle='#7d88ad';c.textAlign='center';c.fillText(r.symbol.slice(0,6),x+bw*0.35,r.pct>=0?mid+13:mid-5);}});
  c.textAlign='left';c.fillStyle='#56608a';c.fillText('+'+mx.toFixed(1)+'%',4,11);c.fillText('-'+mx.toFixed(1)+'%',4,h-3);
}

attachSearch($('#alSearch'),$('#alDD'),it=>{$('#alSearch').value=it.symbol;pickAlert(it.symbol,it.name);});
let alertPickVersion=0;
async function pickAlert(sym,name){
  const version=++alertPickVersion;
  S.alertSel={symbol:sym,name:name||sym};$('#alSym').textContent=sym;$('#alName').textContent=name||'';$('#alPx').textContent='...';
  try{const d=await api('/api/price?symbol='+encodeURIComponent(sym));if(version!==alertPickVersion)return;S.alertPrice=d.price||0;}catch(e){if(version!==alertPickVersion)return;S.alertPrice=0;}
  $('#alPx').textContent=S.alertPrice?fp(S.alertPrice):'Unavailable';calcMove();
}
function calcMove(){
  const t=parseFloat($('#alTarget').value),m=$('#alMove');
  if(!S.alertPrice||isNaN(t)||t<=0){m.className='move';m.textContent='Required move: -';return;}
  const d=(t-S.alertPrice)/S.alertPrice*100;m.className='move '+(d>=0?'up':'dn');
  m.textContent=`Required move: ${fpct(d)} · ${d>=0?'BREAKOUT (price >= target)':'PULLBACK (price <= target)'}`;
}
$('#alTarget').addEventListener('input',calcMove);
$$('#alQuick button').forEach(b=>b.onclick=()=>{if(!S.alertPrice){toast('Select a ticker first',true);return;}const t=S.alertPrice*(1+Number(b.dataset.q)/100);$('#alTarget').value=t.toFixed(S.alertPrice>=1?2:6);calcMove();});
$('#alCreate').onclick=async()=>{
  const t=parseFloat($('#alTarget').value);
  if(!S.alertSel||isNaN(t)||t<=0){toast('Select a ticker and enter a valid target',true);return;}
  if(!(S.alertPrice>0)){toast('Market price unavailable. Reselect the ticker.',true);return;}
  try{await post('/api/alerts',{symbol:S.alertSel.symbol,name:S.alertSel.name,base_price:S.alertPrice,target_price:t,note:$('#alNote').value});
    $('#alTarget').value='';$('#alNote').value='';calcMove();toast('Alert armed');tick();}catch(e){toast(e.message,true);}
};
function renderAlertBook(st){$('#alCount').textContent=st.alerts.length;$('#alTable').innerHTML=alertTable([...st.alerts].reverse(),true);}
$('#alTable').addEventListener('click',alertAction);

function renderDevice(st){
  const d=st.device,dp=st.display;
  if(!S.devInit){S.devInit=true;$('#dvIp').value=d.ip;$('#dvPage').value=dp.page_seconds;$('#dvAlert').value=dp.alert_seconds;$('#dvMover').value=dp.mover_pct;$('#dvMom').value=dp.momentum_pct;}
  const tb=$('#dvToggle');tb.textContent=d.running?'Stop Streaming':'Start Streaming';tb.className='btn '+(d.running?'danger':'primary');
  $('#dvStatus').innerHTML=`Status: ${esc(deviceLabel(d))}<br>Target: <span class="mono">${esc(d.ip)}</span><br>Last successful push: ${d.last_push?ago(d.last_push):'never'}${d.error?`<br><span class="dn small">${esc(d.error)}</span>`:''}`;
  $('#dvPlan').innerHTML=(st.plan||[]).length?st.plan.map(p=>`<div class="plan-row ${p.label===d.label?'cur':''}"><div class="plan-l">${p.label===d.label?'&#9654; ':''}${esc(p.label)}</div><div>${p.symbols.map(s=>`<span class="sym-chip">${esc(s)}</span>`).join('')}</div></div>`).join(''):'<div class="empty">Add tickers to the watchlist</div>';
}
$('#dvSave').onclick=async()=>{try{await post('/api/device',{ip:$('#dvIp').value.trim(),page_seconds:$('#dvPage').value,alert_seconds:$('#dvAlert').value,mover_pct:$('#dvMover').value,momentum_pct:$('#dvMom').value});toast('Device settings saved');tick();}catch(e){toast(e.message,true);}};
$('#dvToggle').onclick=toggleDevice;
$('#dvTest').onclick=async()=>{try{await post('/api/device/push');toast('Screen push requested');setTimeout(tick,1000);}catch(e){toast(e.message,true);}};

setMode(localStorage.getItem('sky_mode')||'advanced');
try{initChart();}catch(e){$('#chartMsg').style.display='grid';$('#chartMsg').textContent='Chart unavailable: '+e.message;}tick();
setInterval(tick,1000);
setInterval(()=>{if(S.view==='screener')loadScreener();},1000);
setInterval(()=>{if(S.view==='dashboard')loadChart(true);},5000);
setInterval(loadDetail,30000);
setInterval(()=>{$('#clock').textContent=new Date().toLocaleTimeString();},1000);
window.addEventListener('resize',()=>{if(S.state)renderWatchlist(S.state);if(S.scr)drawDist($('#scrDist'),[...S.scr.results].sort((a,b)=>b.pct-a.pct));});
</script>
</body>
</html>
"""

# ---------------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    print("\n=========================================")
    print("   SKYLOONG TERMINAL v2.1")
    print("   Open: http://127.0.0.1:5000")
    print(f"   Config: {CONFIG_FILE}")
    print("=========================================\n")
    import logging
    logging.getLogger("werkzeug").setLevel(logging.ERROR)

    with LOCK:
        save_config()   # create the file on first run
    threading.Thread(target=market_loop, daemon=True).start()
    threading.Thread(target=stream_loop, daemon=True).start()
    threading.Thread(target=news_loop, daemon=True).start()
    threading.Thread(target=device_loop, daemon=True).start()
    if CONFIG["screener"].get("enabled"):
        start_screener()
    log_event("system", f"Terminal started · {len(CONFIG['watchlist'])} tickers restored"
                        f"{' · device streaming resumed' if CONFIG['device_running'] else ''}")
    app.run(host="127.0.0.1", port=5000, threaded=True)
