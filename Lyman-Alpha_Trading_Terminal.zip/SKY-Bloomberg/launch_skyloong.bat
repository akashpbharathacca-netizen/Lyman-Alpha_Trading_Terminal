@echo off
title SKYLOONG RETRO TERMINAL
cd /d "E:\Akash-Bakupo\AI\Python Repos\SKY-Bloomberg"

where python >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Python not found in PATH.
    pause
    exit /b 1
)

python -c "import flask, yfinance, requests, PIL" >nul 2>nul
if errorlevel 1 (
    echo Installing missing dependencies...
    python -m pip install flask yfinance requests pillow
)

start "" /b cmd /c "timeout /t 3 /nobreak >nul && start http://127.0.0.1:5000"
python "skyloong_terminal.py"

echo.
echo Server stopped.
pause
